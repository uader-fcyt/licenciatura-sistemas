#include <iostream>
#include <iomanip>
using namespace std;

struct Datos {int dni;
              char sexo;
			  int edad;};
	
int main(int argc, char *argv[]) {
	int Mat[10][3];
	int nDoc,nEdad,nPreg,nResp,nCant;
	char cSexo;
	Datos encuestados[1000];
	int nI,nJ;
	for (nI=0;nI<10;nI++)
		for (nJ=0;nJ<3;nJ++)
			Mat[nI][nJ]=0;
	nCant=0;		
	cout<<"Ingrese dni: ";
	cin>>nDoc;
	while(nDoc!=999)
	{
		cout<<"Ingrese Sexo: ";
		cin>>cSexo;
		cout<<"Ingrese edad: ";
		cin>>nEdad;
		for (nI=0;nI<10;nI++)
		{
			cout<<"Ingrese Nro Pregunta: ";
			cin>>nPreg;
			cout<<"Ingrese Respuesta: ";
			cin>>nResp;
			Mat[nPreg-1][nResp-1]=Mat[nPreg-1][nResp-1]+1;
		}
		encuestados[nCant].dni=nDoc;
		encuestados[nCant].sexo=cSexo;
		encuestados[nCant].edad=nEdad;
		nCant++;
		
		cout<<"Ingrese dni: ";
		cin>>nDoc;
	}
	cout <<"Punto a)"<<endl;
	cout <<setw(5)<<" "<<setw(5)<<1<<setw(5)<<2<<setw(5)<<3<<endl;
	for (nI=0;nI<10;nI++)
	{
		cout<<setw(5)<<nI+1;
		for (nJ=0;nJ<3;nJ++)
		{
			cout<<setw(5)<<Mat[nI][nJ];
		}
		cout<<endl;
		
	};
	for (nI=0;nI<nCant-1;nI++)
	{
		for (nJ=nI+1;nJ<nCant;nJ++)
			if (encuestados[nI].dni>encuestados[nJ].dni)
			{
				Datos Aux=encuestados[nI];
				encuestados[nI]=encuestados[nJ];
				encuestados[nJ]=Aux;
			}
	}
	cout<<"Punto b)"<<endl;
	cout<<setw(8)<<"dni"<<setw(4)<<"sexo"<<setw(5)<<"edad"<<endl;
	for (nI=0;nI<nCant;nI++)
	{
		cout <<setw(8)<<encuestados[nI].dni<<setw(4)<<encuestados[nI].sexo<<setw(5)<<encuestados[nI].edad<<endl;			
		
	}
		
	return 0;
}

