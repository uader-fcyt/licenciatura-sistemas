#include <iostream>
using namespace std;

int bbb=2;

int main(int argc, char *argv[]) {
	int nCantidad,nDeACuantos;
	cout << "COMBINATORIA"<<endl;
	cout << "Ingrese cantidad de elementos: ";
	cin >> nCantidad;
	cout << "Ingrese 'Tomados de a cuantos':";
	cin >> nDeACuantos;
// ------------- Factorial de nCantidad	
	int nI=1;
	double nAux1=1;
	while (nI<=nCantidad) {
		nAux1=nAux1*nI;
		nI++;
	}
	// ------------- Factorial de nDeACuantos	
	nI=1;
	double nAux2=1;
	while (nI<=nDeACuantos) {
		nAux2=nAux2*nI;
		nI++;
	}
// ------------- Factorial de nCantidad-nDeACuantos	
	nI=1;
	double nAux3=1;
	while (nI<=(nCantidad-nDeACuantos)) {
		nAux3=nAux3*nI;
		nI++;
	}
	
	double nCombi = nAux1 / (nAux2*nAux3);
	cout << "Cantidad de Combinaciones Posibles: "<< nCombi;
	return 0;
}

