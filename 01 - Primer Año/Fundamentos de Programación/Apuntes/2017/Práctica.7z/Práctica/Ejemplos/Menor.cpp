#include <iostream>
using namespace std;

int Menor(int a,int b=0);
float Menor(float x,float y=0);

void SaltoDeLinea();

int main(int argc, char *argv[]) {
	int nValor1,nValor2;
	float nValor3,nValor4;
	cout << "Ingrese Primer Valor: ";
	cin >> nValor1;
	cout << "Ingrese Segundo Valor: ";
	cin >> nValor2;
	cout << "El menor es: "<< Menor(nValor1);
    SaltoDeLinea();
	cout << "El menor es: "<< Menor(nValor1,nValor2);
	nValor3=nValor1;
	nValor4=nValor2;
	SaltoDeLinea();
	cout << "El menor es: "<< Menor(nValor3,nValor4);
	
	return 0;
}

void SaltoDeLinea() {
	cout << endl;
}
	

int Menor(int a,int b) {
	int nAux;
	if (a>=b)
		nAux=b;
	else
		nAux=a;
    a=100;
	b=4;
	
	return nAux;
	
}

float Menor(float a,float b) {
	float nAux;
	if (a>=b)
		nAux=b*100;
	else
		nAux=a*100;
	
	return nAux;
	
}
