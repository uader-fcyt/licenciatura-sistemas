#include <iostream>
#include <fstream>
using namespace std;

int main(int argc, char *argv[]) {
	string cApodo;
	int nCant;
	ofstream Arch;
	Arch.open("./BARRAS.TXT");
	cout <<"Apodo: ";
	getline(cin,cApodo);
	while (cApodo!="ZZZ") {
		cout <<"Cantidad de Detenciones: ";
		cin >> nCant;
		Arch << cApodo << endl;
		Arch << nCant << endl;
		cin.get();
		cout <<"Apodo: ";
		getline(cin,cApodo);
	}
	Arch.close();
	return 0;
}

