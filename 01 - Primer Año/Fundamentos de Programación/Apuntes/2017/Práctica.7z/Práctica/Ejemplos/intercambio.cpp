#include <iostream>
using namespace std;

void Intercambio(int &a,int &b);

int main(int argc, char *argv[]) {
	int nValor1,nValor2;
	cout << "Ingrese Primer Valor: ";
	cin >> nValor1;
	cout << "Ingrese Segundo Valor: ";
	cin >> nValor2;
	cout << "INTERCAMBIO "<<endl;
	Intercambio(nValor1,nValor2);
	cout << "Primer Valor: "<<nValor1<<endl;
	cout << "Segundo Valor: "<<nValor2<<endl;
	return 0;
}

void Intercambio(int &a,int &b) {
	int nAux =a;
	a = b;
	b=nAux;
}
