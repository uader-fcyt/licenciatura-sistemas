#include <iostream>
using namespace std;

int bbb=2;

double factorial(int nNumero);

int main(int argc, char *argv[]) {
	int nCantidad,nDeACuantos;
	cout << "COMBINATORIA"<<endl;
	cout << "Ingrese cantidad de elementos: ";
	cin >> nCantidad;
	cout << "Ingrese 'Tomados de a cuantos':";
	cin >> nDeACuantos;
	
	double nCombi = factorial(nCantidad) / (factorial(nDeACuantos)*factorial(nCantidad-nDeACuantos));
	
	cout << "Cantidad de Combinaciones Posibles: "<< nCombi;
	return 0;
}

double factorial(int nNumero) {
	int nI=1;
	double nAux=1;
	while (nI<=nNumero) {
		nAux=nAux*nI;
		nI++;
	}
	return nAux*bbb;
}
