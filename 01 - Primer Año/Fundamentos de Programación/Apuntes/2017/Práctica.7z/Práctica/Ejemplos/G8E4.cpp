#include <iostream>
#include <fstream>
#include <cstdlib>
using namespace std;

int main(int argc, char *argv[]) {
	string cApodo,cAux;
	int nCant;
	int nDeten1=0,nDeten2a4=0,nDeten5a10=0,nDetenMas10=0;
	ifstream Arch;
	Arch.open("./BARRAS.TXT");
	getline(Arch,cApodo);
	cout << "Apodo: "<< cApodo <<endl;
	while (!Arch.eof()) {
		Arch >> cAux;
		nCant=atoi(cAux.c_str());
		cout << "Cantidad:"<< cAux <<endl;
		if (nCant < 2)
			nDeten1++;
		else if (nCant<5)
				nDeten2a4++;
		else if (nCant <11)
					nDeten5a10++;
		else
					nDetenMas10++;
		Arch.get();
		getline(Arch,cApodo);
		cout << "Apodo: "<<cApodo <<endl;
		
	}
	Arch.close();
	cout << "Cantidad de Detenciones  Cantidad de Integrantes"<<endl;
	cout << "        1                " << nDeten1 << endl;
	cout << "      2 a 4              " << nDeten2a4 << endl;
	cout << "      5 a 10             " << nDeten5a10 << endl;
	cout << "      mas de 10          " << nDetenMas10 << endl;
	
	return 0;
}
