/*
 * Guia5-Eje01.cpp
 *
 *  Created on: 5 oct. 2017
 *      Author: chinosoliard
 *
 *  Generar un vector llamado MUL, donde sus elementos sean los múltiplos de 3, desde 3
 *  hasta N inclusive. El valor N se ingresa como primer dato.
 */

#include <iostream>
using namespace std;

int main(){
	int N;
	cout << "Ingrese N:";
	cin >> N;
	int MUL[N];
	for(int i=0; i<N; i++){
		MUL[i] = 3*(i+1);
	}

	for(int i; i<N; i++){
		cout << MUL[i] << endl;
	}
}


