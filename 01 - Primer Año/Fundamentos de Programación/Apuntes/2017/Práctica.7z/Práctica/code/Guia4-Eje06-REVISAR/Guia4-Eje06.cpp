/*
 * Guia4-Eje06.cpp
 *
 *  Created on: 3 oct. 2017
 *      Author: chinosoliard
 *
 *  Se evalúa el movimiento anual en una determinada empresa en millones de pesos.
 *  Seingresa por cada mes los montos que ingresan y egresan. Informar:
 *  	Mes			Ingreso			Egreso			Saldo
 *  	***			***				***				***
 *  	_______________________________________________
 *  						Saldo Promedio 			***
 *  Indicar además si el resultado del balance fue POSITIVO o NEGATIVO con un mensaje
 *  alusivo
 */

#include <iostream>
using namespace std;


int main(){

}
