/*
 * Guia0-Eje4.cpp
 *
 *  Created on: 30 ago. 2017
 *      Author: chinosoliard
 *
 *  Un almacén de barrio necesita un programa para calcular el total a cobrar a un cliente por
 *  una compra. Se ingresan los datos de la venta: Nombre y Apellido del cliente, cantidad
 *  comprada del artículo y precio unitario del mismo. Al monto total de la venta, se le efectúa
 *  un descuento del 5%. Luego de realizado el descuento se calcula el IVA del 21% para obtener
 *  el total a pagar.
 */

# include <iostream>
using namespace std;
# include <string>
using namespace std;

string nombre, apellido;
int cantidadComprada;
float precioUnitario, subtotal, descuento, IVA, totalAPagar;

int main(){
	cout << "Ingrese nombre del cliente: ";
	cin >> nombre;
	cout << "Ingrese apellido del cliente: ";
	cin >> apellido;
	cout << "Ingrese la cantidad comprada del artículo: ";
	cin >> cantidadComprada;
	cout << "Ingrese el precio unitario del articulo: ";
	cin >> precioUnitario;
	subtotal = (cantidadComprada*precioUnitario);
	descuento = subtotal * 0.05;
	IVA = (subtotal-descuento)*0.21;
	totalAPagar = subtotal - descuento - IVA;
	cout << "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-" << endl;
	cout << "Cliente: " << nombre << " " << apellido << endl;
	cout << "Subtotal: " << subtotal << endl;
	cout << "Descuento: " << descuento << endl;
	cout << "IVA: " << IVA << endl;
	cout << "··········································" << endl;
	cout << "TOTAL A PAGAR: " << totalAPagar;
}




