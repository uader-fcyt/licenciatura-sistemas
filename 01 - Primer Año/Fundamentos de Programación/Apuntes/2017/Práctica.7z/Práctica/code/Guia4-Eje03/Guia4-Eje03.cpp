/*
 * Guia4-Eje03.cpp
 *
 *  Created on: 3 oct. 2017
 *      Author: chinosoliard
 *
 *  Dados dos números tomados como entrada, mostrar por pantalla su división entera
 *  (cociente y resto). Evitaremos utilizar los operadores predefinidos disponibles
 *  en C++ para ello (/ y %). En su lugar, aprovecharemos que la división entera no
 *  es más que el resultado de una serie de restas sucesivas del divisor al dividendo,
 *  hasta que no sea posible continuar.
 */

#include <iostream>
using namespace std;

int numero1, numero2, resto, cociente;

int main(){
	cout << "Ingrese el primer número: ";
	cin >> numero1;
	cout << "Ingrese el segundo número: ";
	cin >> numero2;

	resto = numero1;
	while(resto >= numero2){
		cociente++;
		resto-=numero2;
	}

	cout << "cociente: " << cociente << endl;
	cout << "resto: " << resto << endl;

}




