/*
 * Guia8-Eje10.cpp
 *
 *  Created on: 1 nov. 2017
 *      Author: chinosoliard
 *
 *  Se desea realizar un informe ordenado por el sueldo a percibir por cada empleado de mayor a
 *  menor con la información existente em el archivo SUELDOS.TXT.
 */

#include <iostream>
#include <string>
#include <fstream>
using namespace std;

ifstream archivo;
string path = "../Guia8-Eje09/SUELDOS.TXT";
struct dato{ int codigoEmpleado; double sueldo; };

/* Abre el archivo cuya dirección se especifica en "direccion". Si hay error devuelve false.
 Si existe ya un archivo abierto en "archivo", lo cierra y borra las banderas de estado. */
bool abrirArchivo(string direccion){
	if(archivo.is_open()){
		archivo.clear();
		archivo.seekg(0);
	}
	else{
		archivo.open(direccion);
	}
	if(archivo.fail()){
		return false;
	}
	else return true;
}

/* Cuenta el total de lineas del archivo y calcula el total de registros,
 * es decir, divide el total de lineas por 2, que son la cantidad de datos
 * por registro (codigoEmpleado y sueldo). Al finalizar, abre de nuevo el archivo
 * para que se reinicien las banderas de estado.
 */
int contarRegistros(){
	int cantidad = 0;
	int contador = 0;
	while(!archivo.eof()){
		string valor;
		contador++;
		getline(archivo, valor);
	}
	cantidad = contador/2;
	if(!abrirArchivo(path)){
		cout << "Error en apertura del archivo" ;
		return 0;
	}
	return cantidad;
}

/* Ordena la lista, conociendo el número de registros.
 * Como parametros, recibe la lista de datos y la cantidad de registros.
 */
void ordenarLista(dato datos[], int cantidadRegistros){
	int mayor = 0;
	for (int i = 0; i < cantidadRegistros; i++){
		for(int j = i+1; j < cantidadRegistros; j++){
			if(datos[j].sueldo > datos[mayor].sueldo){
				mayor = j;
			}
		}
		dato auxiliar = datos[i];
		datos[i] = datos[mayor];
		datos[mayor] = auxiliar;
	}
}

int main(){
	if(!abrirArchivo(path)){
		cout << "Error en apertura del archivo" ;
		return 0;
	}
	int cantidadRegistros = contarRegistros();
	dato datos[cantidadRegistros];
	if(abrirArchivo(path)){
		for(int i = 0; i<cantidadRegistros;i++){
			string aux;
			getline(archivo, aux);
			datos[i].codigoEmpleado = atoi(aux.c_str());
			getline(archivo, aux);
			datos[i].sueldo = atof(aux.c_str());
		}
	}
	else{
		cout << "Falló reinicio de posición archivo";
		return 0;
	}

	ordenarLista(datos, cantidadRegistros);

	cout << "codigoEmpleado" << "		";
	cout << "Sueldo" << endl;
	for(int i = 0; i< cantidadRegistros; i++){
		cout << datos[i].codigoEmpleado << "			";
		cout << datos[i].sueldo << endl;
	}
	return 0;
}



