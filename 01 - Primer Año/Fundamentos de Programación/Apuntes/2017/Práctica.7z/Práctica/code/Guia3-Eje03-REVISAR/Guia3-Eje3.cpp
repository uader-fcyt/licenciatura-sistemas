/*
 * Guia3-Eje3.cpp
 *
 *  Created on: 2 oct. 2017
 *      Author: chinosoliard
 *
 *  Dadas 3 cadenas de caracteres, informar si alguna de las tres está incluída en alguna
 *  de las otras.
 *  Ayuda: Ver la operación find().
 */

#include <iostream>
#include <string>
using namespace std;

string cadena1, cadena2, cadena3;

int main(){
	cout << "Ingrese cadena1: " << endl;
	getline(cin, cadena1);
	cout << "Ingrese cadena2: " << endl;
	getline(cin, cadena2);
	cout << "Ingrese cadena3: " << endl;
	getline(cin, cadena3);


	if(cadena1.find(cadena2)){
		cout << "la cadena2 (" << cadena2 << ") está contenida en la cadena1 (" << cadena1 << ")" << endl;
	}
	if(cadena1.find(cadena3)){
		cout << "la cadena3 (" << cadena3 << ") está contenida en la cadena1 (" << cadena1 << ")" << endl;
	}

	if(cadena2.find(cadena1)){
		cout << "la cadena1 (" << cadena1 << ") está contenida en la cadena2 (" << cadena2 << ")" << endl;
	}
	if(cadena2.find(cadena3)){
		cout << "la cadena3 (" << cadena3 << ") está contenida en la cadena2 (" << cadena2 << ")" << endl;
	}

	if(cadena3.find(cadena1)){
		cout << "la cadena1 (" << cadena1 << ") está contenida en la cadena3 (" << cadena3 << ")" << endl;
	}
	if(cadena3.find(cadena2)){
		cout << "la cadena2 (" << cadena2 << ") está contenida en la cadena3 (" << cadena3 << ")" << endl;
	}
}


