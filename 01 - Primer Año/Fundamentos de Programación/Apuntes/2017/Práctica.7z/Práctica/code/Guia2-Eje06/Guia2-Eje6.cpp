/*
 * Guia2-Eje6.cpp
 *
 *  Created on: 1 oct. 2017
 *      Author: chinosoliard
 *
 * Dadas las longitudes de los lados de un triángulo, determinar el
 * tipo de triángulo (equilátero, isósceles o escaleno) e informar
 * su perímetro y su tipo.
 */

#include <iostream>
using namespace std;

int lado1, lado2, lado3, perimetro;

int main(){
	cout << "Ingrese el lado 1: ";
	cin >> lado1;
	cout << "Ingrese el lado 2: ";
	cin >> lado2;
	cout << "Ingrese el lado 3: ";
	cin >> lado3;

	if (lado1 == lado2 && lado2 == lado3){
		cout << "el triangulo es equilatero" << endl;
	}
	else if (lado1 == lado2 || lado2 == lado3 || lado3 == lado1){
		cout << "el triangulo es isóceles" << endl;
	}
	else{
		cout << "el triangulo es escaleno" << endl;
	}

	perimetro = lado1 + lado2 + lado3;
	cout << "El perimetro del triangulo es de " << perimetro << endl;
}


