/*
 * Guia4-Eje07.cpp
 *
 *  Created on: 3 oct. 2017
 *      Author: chinosoliard
 *
 *  Un jardín de infantes tiene N alumnos y desea hacer un control de los mismos.
 *  Por cada alumno se ingresa Nombre y Apellido, Peso y Altura.
 *  Informar cuál es el alumno más alto y cuál es el de menor peso.
 *  El Valor N se ingresa como primer dato.
 */

#include <iostream>
#include <string>
using namespace std;

int contador, N, pesoMenor, alturaMayor, peso, altura;
string nomApe, nomApeMenorPeso, nomApeMasAlto;

int main(){
	cout << "Ingrese la cantidad de alumnos: ";
	cin >> N;

	while(contador < N){
		cout << "Nombre y Apellido del alumno: ";
		cin.get();
		getline(cin, nomApe);
		cout << "Peso del alumno: ";
		cin >> peso;
		cout << "Altura del alumno: ";
		cin >> altura;

		if(altura > alturaMayor){
			alturaMayor = altura;
			nomApeMasAlto = nomApe;
		}

		if((peso < pesoMenor) || (pesoMenor ==0)){
			pesoMenor = peso;
			nomApeMenorPeso = nomApe;
		}
		contador++;
	}

	cout << "El alumno con mayor altura (" << alturaMayor << ") es " << nomApeMasAlto << endl;
	cout << "El alumno con menor peso (" << pesoMenor << ") es " << nomApeMenorPeso << endl;
}


