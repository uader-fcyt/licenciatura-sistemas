/*
 * Eje1.cpp
 *
 *  Created on: 28 de mar. de 2017
 *      Author: chinosoliard
 */

#include <iostream>
using namespace std;
#include <math.h>
using namespace std;

int radio, altura;
float volumen;

int main(){
	cout << "Ingrese el radio del cilindro: ";
	cin >> radio;
	cout << "Ingrese la altura del cilindro: ";
	cin >> altura;
	volumen = altura*(3.14)*pow(radio, 2);
	cout << "El volumen del cilindro es de: " << volumen;
	return 0;
}
