/*
 * Guia2-Eje09.cpp
 *
 *  Created on: 1 oct. 2017
 *      Author: chinosoliard
 *
 *  Determinar si un año ingresado por el usuario es bisiesto. Un año es bisiesto si
 *  es divisible entre 4, a menos que sea divisible entre 100. Sin embargo, si un año
 *  es divisible entre 100 y además es divisible entre 400, también resulta bisiesto.
 */

#include <iostream>
using namespace std;

int anio;

int main(){
	cout << "Ingrese el año: ";
	cin >> anio;
	if((anio % 100 == 0) && (anio % 400 == 0)){
		cout << "El año es bisiesto";
	}
	else if((anio % 4 == 0) && (anio % 100 == 0)){
		cout << "El año no es bisiesto";
	}
	else if(anio % 4 == 0){
		cout << "El año es bisiesto";
	}

	return 0;
}
