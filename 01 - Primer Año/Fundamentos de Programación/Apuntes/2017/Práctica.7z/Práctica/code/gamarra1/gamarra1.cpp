#include <iostream>
#include <fstream>
#include <cmath>
#include <cstdlib>
using namespace std;
/*Se desea generar un archivo de texto que guarde los valores de x e y donde y = a x2 + bx + c.
	Los valores de a, b y c son ingresados por teclado. Los valores de x son numeros enteros desde 1
	hasta 1000.*/


int main(int argc, char *argv[]) {
	ofstream archivo;
	archivo.open("./variables.TXT");
	int a=0,b=0,c=0;
	cout<<"ingrese el valor de a:";
	cin>>a;
	cout<<"ingrese el valor de b:";
	cin>>b;cout<<"ingrese el valor de c:";
	cin>>c;
	int i=0;
	int x[10],y[10];
	for( i=0;i<10 ; i++){
		x[i]=i;
		y[i] = a*pow(x[i],2)+b*x[i]+c;
	}
	for(i=0; i<10;i++){
		archivo<<y[i]<<endl<<x[i]<<endl;
	}
	archivo.close();
	return 0;
}
