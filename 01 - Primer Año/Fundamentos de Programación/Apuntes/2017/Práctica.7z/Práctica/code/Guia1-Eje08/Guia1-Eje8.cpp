/*
 * Guia1-Eje8.cpp
 *
 *  Created on: 7 sep. 2017
 *      Author: chinosoliard
 *
 *  Una empresa que comercializa artefactos electrodomésticos posee 2 sucursales.
 *  De cada una de ellas se conocen los montos de ventas semestrales realizadas
 *  durante el año 2016. Estos datos se ingresan ordenados por sucursal y por semestre.
 *  Cada sucursal destinó el 20% del total de sus ventas para pagar una bonificación
 *  a sus empleados; monto que se repartió en partes iguales entre ellos. Se ingresan
 *  también, la cantidad de empleados que tenían las sucursales en el 2016.
 *  Determinar e informar:
 *  a. El total de ventas de cada sucursal.
 *  b. La bonificación que pagó cada sucursal a cada empleado.
 */

#include <iostream>
using namespace std;

float sucursal1sem1, sucursal1sem2, sucursal2sem1, sucursal2sem2, ventasAnualSuc1, ventasAnualSuc2, bonSucursal1, bonSucursal2;
int cantEmpleadosSucursal1, cantEmpleadosSucursal2;

int main(){
	cout << "Sucursal 1" << endl;
	cout << "==========" << endl;
	cout << "Ingrese las ventas del primer semestre: ";
	cin >> sucursal1sem1;
	cout << "Ingrese las ventas del segundo semestre: ";
	cin >> sucursal1sem2;
	cout << "Ingrese la cantidad de empleados: ";
	cin >> cantEmpleadosSucursal1;
	cout << "Sucursal 2" << endl;
	cout << "==========" << endl;
	cout << "Ingrese las ventas del primer semestre: ";
	cin >> sucursal2sem1;
	cout << "Ingrese las ventas del segundo semestre: ";
	cin >> sucursal2sem2;
	cout << "Ingrese la cantidad de empleados: ";
	cin >> cantEmpleadosSucursal2;
	cout << "===========================================" << endl;

	ventasAnualSuc1 = sucursal1sem1 + sucursal1sem2;
	ventasAnualSuc2 = sucursal2sem1 + sucursal2sem2;
	bonSucursal1 = (ventasAnualSuc1*0.2) / cantEmpleadosSucursal1;
	bonSucursal2 = (ventasAnualSuc2*0.2) / cantEmpleadosSucursal2;

	cout << "Total ventas sucursal 1: " << ventasAnualSuc1 << endl;
	cout << "Bonificación correspondiente a cada empleado: " << bonSucursal1 << endl;
	cout << "___________________________________________" << endl;
	cout << "Total ventas sucursal 2: " << ventasAnualSuc2 << endl;
	cout << "Bonificación correspondiente a cada empleado: " << bonSucursal2 << endl;

	return 0;
}


