/*
 * Guia4-Eje04.cpp
 *
 *  Created on: 3 oct. 2017
 *      Author: chinosoliard
 *
 *  Calcular la media de X cantidad de números, para lo cual se ingresarán valores
 *  enteros reiteradamente, siendo el fin de la carga, un valor igual a 0. Informar
 *  el valor medio y la cantidad de datos ingresados.
 */

#include <iostream>
using namespace std;

int numero, contador;
float media = 0.0;

int main(){
	cout << "Ingrese un número: ";
	cin >> numero;
	while(numero != 0){
		media+=(numero/2);
		contador++;
		cout << "Ingrese un número: ";
		cin >> numero;
	}

	cout << "Valor medio: " << media << endl;
	cout << "Cantidad de datos ingresados: " << contador;
}


