/*
 * Guia3-Eje7.cpp
 *
 *  Created on: 3 oct. 2017
 *      Author: chinosoliard
 *
 *  Dadas 3 cadenas de caracteres, ordenarlas de acuerdo a su largo
 */

#include <iostream>
#include <string>
using namespace std;

string cadena1, cadena2, cadena3, mayor, menor, media;

int main(){
	cout << "Ingrese cadena 1: " << endl;
	getline(cin, cadena1);
	cout << "Ingrese cadena 2: " << endl;
	getline(cin, cadena2);
	cout << "Ingrese cadena 3: " << endl;
	getline(cin, cadena3);

	if((cadena1.size() > cadena2.size()) && cadena1.size() > cadena3.size()){
		mayor = cadena1;
	}
	else if((cadena2.size() > cadena1.size()) && cadena2.size() > cadena3.size()){
		mayor = cadena2;
	}
	else if((cadena3.size() > cadena1.size()) && cadena3.size() > cadena2.size()){
		mayor = cadena3;
	}

	if((cadena1.size() < cadena2.size()) && cadena1.size() < cadena3.size()){
		menor = cadena1;
	}
	else if((cadena2.size() < cadena1.size()) && cadena2.size() < cadena3.size()){
		menor = cadena2;
	}
	else if((cadena3.size() < cadena1.size()) && cadena3.size() < cadena2.size()){
		menor = cadena3;
	}

	if((mayor != cadena1) && (menor != cadena1)){
		media = cadena1;
	}
	else if((mayor != cadena2) && (menor != cadena2)){
		media = cadena2;
	}
	else if((mayor != cadena3) && (menor != cadena3)){
		media = cadena3;
	}

	cout << "Mayor: " << mayor << endl;
	cout << "Media: " << media << endl;
	cout << "Menor: " << menor << endl;
}
