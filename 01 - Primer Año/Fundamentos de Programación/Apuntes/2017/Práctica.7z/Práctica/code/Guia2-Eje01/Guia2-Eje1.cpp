/*
 * Guia2-Eje1.cpp
 *
 *  Created on: 13 sep. 2017
 *      Author: chinosoliard
 *
 * Utilice la notación de los operadores aritméticos y funciones matemáticas que provee C++
 * para escribir las siguientes expresiones. Si le facilita la tarea, puede utilizar variables
 * auxiliares.
 * a) (-b + RAIZ( b² - 4ac))/2.ab)
 *
 * b) ln(2x-1)+((-e^2x + RAIZ5(x^a - 3ax))/2x-1
 *
 * c) ((e^a)/(a-x)) + ((e(a+z).sen(a-x)+e^x2)/2)
 *
 * Obs: deberá utilizar las funciones potencia (pow( )), raíz cuadrada(sqrt( )), logaritmo
 * natural (log( )) y seno (sin( )) que se encuentran en la biblioteca math.h.
 */

#include <iostream>
#include <math.h>
using namespace std;

int a, b, c, x;
float ejercicioA, ejercicioB, ejercicioC;
int main (){
	cout << "Ingrese el valor de a: ";
	cin >> a;
	cout << "Ingrese el valor de b: ";
	cin >> b;
	cout << "Ingrese el valor de c: ";
	cin >> c;
	cout << "Ingrese el valor de x: ";
	cin >> x;

	ejercicioA = ((b*-1)+(sqrt(pow(b,2)-(4*a*b))))/2*a;

	ejercicioB = (log((2*x)-1))+()

}


