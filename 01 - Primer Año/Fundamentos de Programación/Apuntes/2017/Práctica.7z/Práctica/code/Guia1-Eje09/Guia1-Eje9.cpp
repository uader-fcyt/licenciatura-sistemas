/*
 * Guia1-Eje9.cpp
 *
 *  Created on: 7 sep. 2017
 *      Author: chinosoliard
 *
 *  Una línea de colectivos presta los siguientes servicios: Común, Estudiante y Trabajador.
 *  Los estudiantes y los trabajadores abonan el 50 % y el 40 % del costo de un boleto común,
 *  respectivamente. Se desea obtener cantidad de boletos vendidos según el servicio y total
 *  recaudado. Para resolver el problema se dispone de las numeraciones iniciales y finales
 *  de los boletos de cada uno de los servicios, además se conoce al inicio el precio del
 *  boleto estudiante.
 *
 */

#include <iostream>
using namespace std;

float precioComun, precioEstudiante, precioTrabajador, totalRecComun, totalRecEst, totalRecTrab, totalRecaudado;
int inicioComun, finComun, inicioEstudiante, finEstudiante, inicioTrabajador, finTrabajador, totalComun, totalEstudiante, totalTrabajador;

int main() {
	cout << "Ingrese el monto del pasaje estudiantíl: ";
	cin >> precioEstudiante;
	precioComun = precioEstudiante*2;
	precioTrabajador = precioComun*0.4;
	cout << "=======================================" << endl;
	cout << "Número inicial pasaje común: ";
	cin >> inicioComun;
	cout << "Número final pasaje común: ";
	cin >> finComun;
	cout << "Número inicial pasaje estudiante: ";
	cin >> inicioEstudiante;
	cout << "Número final pasaje estudiante: ";
	cin >> finEstudiante;
	cout << "Número inicial pasaje trabajador: ";
	cin >> inicioTrabajador;
	cout << "Número final pasaje trabajador: ";
	cin >> finTrabajador;
	totalComun = (finComun+1)-inicioComun;
	totalEstudiante = (finEstudiante+1)-inicioEstudiante;
	totalTrabajador = (finTrabajador+1)-inicioTrabajador;
	totalRecComun = totalComun*precioComun;
	totalRecEst = totalEstudiante*precioEstudiante;
	totalRecTrab = totalTrabajador*precioTrabajador;
	totalRecaudado = totalRecTrab+totalRecEst+totalRecComun;
	cout << "=======================================" << endl;
	cout << "Cantidad de pasajes de comunes: " << totalComun << " - Recaudado: " << totalRecComun << endl;
	cout << "Cantidad de pasajes de estudiantes: " << totalEstudiante << " - Recaudado: " << totalRecEst << endl;
	cout << "Cantidad de pasajes de trabajador: " << totalTrabajador << " - Recaudado: " << totalRecTrab << endl;
	cout << "_______________________________________" << endl;
	cout << "Total recaudado: " << totalRecaudado << endl;

	return 0;
}
