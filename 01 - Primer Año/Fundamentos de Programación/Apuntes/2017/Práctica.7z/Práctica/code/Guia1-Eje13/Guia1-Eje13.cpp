/*
 * Guia1-Eje13.cpp
 *
 *  Created on: 8 sep. 2017
 *      Author: chinosoliard
 *
 *  Escribir programa que ingrese una cantidad de dinero en pesos y la cotización del dólar, euro y real, luego informe:
 *  a) Su equivalente en Dólares.
 *  b) Su equivalente en Euros.
 *  c) Su equivalente en Reales.
 *
 */

#include <iostream>
using namespace std;

float cotizDolar, cotizEuro, cotizReal, dineroPesos;

int main(){
	cout << "Ingrese la cantidad de pesos: ";
	cin >> dineroPesos;
	cout << "Ingrese la cotización actual del dolar: ";
	cin >> cotizDolar;
	cout << "Ingrese la cotización actual del euro: ";
	cin >> cotizEuro;
	cout << "Ingrese la cotización actual del real: ";
	cin >> cotizReal;

	cout << "Sus " << dineroPesos << "$ equivalen a:" << endl;
	cout << dineroPesos/cotizDolar << " dolares" << endl;
	cout << dineroPesos/cotizEuro << " euros" << endl;
	cout << dineroPesos/cotizReal << " reales" << endl;

	return 0;
}


