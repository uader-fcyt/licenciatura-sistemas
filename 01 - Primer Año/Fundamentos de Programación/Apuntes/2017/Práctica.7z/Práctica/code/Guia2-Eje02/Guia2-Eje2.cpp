/*
 * Guia2-Eje2.cpp
 *
 *  Created on: 13 sep. 2017
 *      Author: chinosoliard
 *
 *  Utilice los operadores aritméticos de C++ para plantear las expresiones que se proponen
 *  coloquialmente. Si es posible, exprese también la forma abreviada correspondiente
 *  (utilizando operadores relativos de asignación).
 *  a) El cociente entre m y n, almacenado en z.
 *  b) El resto de la división entera entre p y q, almacenado en y.
 *  c) Incrementar x en 1.
 *  d) Incrementar x sumando a x el contenido de c.
 *  e) Modificar z, asignándole el valor que precede a z.
 */

#include <iostream>
using namespace std;

int m, n, z, p, q, y, x, c;

int main(){
	cout << "Ingrese el valor de m: ";
	cin >> m;
	cout << "Ingrese el valor de n: ";
	cin >> n;

	cout << "Ingrese el valor de p: ";
	cin >> p;
	cout << "Ingrese el valor de q: ";
	cin >> q;
	cout << "Ingrese el valor de x: ";
	cin >> x;

	cout << "Ingrese el valor de c: ";
	cin >> c;

	z = m*n;
	cout << "El cociente entre m y n, almacenado en z.: " << z << endl;

	y = p%q;
	cout << "El resto de la división entera entre p y q, almacenado en y: " << y << endl;

	x++;
	cout << "Incrementar x en 1.: " << x << endl;

	x += c;
	cout << "Incrementar x sumando a x el contenido de c: " << x << endl;

	z--;
	cout << "Modificar z, asignándole el valor que precede a z: " << z << endl;
}


