/*
 * Guia4-Eje08.cpp
 *
 *  Created on: 3 oct. 2017
 *      Author: chinosoliard
 *
 *  El colegio de médicos ha organizado un curso y desea saber cuántas mujeres y cuántos
 *  varones asistieron al mismo.
 *  Para ello, se ingresa por cada participante: Nombre y apellido, edad y sexo (‘F’ ‘M’).
 *  El ingreso de datos finaliza cuando se ingresa un nombre y apellido igual a XXX.
 *  Calcular e informar:
 *  • Cantidad de mujeres y de varones que asistieron al curso.
 *  • Cantidad de mujeres mayores de 25 años que asistieron.
 *  • Cantidad de hombres menores de 40 años que asistieron.
 *  • Cantidad total de participantes.
 */

#include <iostream>
#include <string>
using namespace std;

string nombreApellido;
int edad, cantMujeres, cantVarones, cantMujeres25, cantVarones40, cantidad;
char sexo;

int main(){
	cout << "Ingrese nombre y apellido: ";
	cin.get();
	getline(cin, nombreApellido);
	while(nombreApellido != "XXX"){

		cout << "Ingrese edad: ";
		cin >> edad;
		cout << "Ingrese sexo (F o M): ";
		cin >> sexo;
		cantidad++;
		if(sexo == 'F'){
			cantMujeres++;
			if(edad > 25){
				cantMujeres25++;
			}
		}
		if(sexo == 'M'){
			cantVarones++;
			if(edad > 40){
				cantVarones40++;
			}
		}
		cout << "Ingrese nombre y apellido: ";
		cin.get();
		getline(cin, nombreApellido);
	}

	cout << "Cantidad de mujeres que asistieron: " << cantMujeres << endl;
	cout << "Cantidad de hombres que asistieron: " << cantVarones << endl;
	cout << "Cantidad de mujeres mayores de 25 años que asistieron: " << cantMujeres25 << endl;
	cout << "Cantidad de hombres mayores de 40 años que asistieron: " << cantVarones40 << endl;
	cout << "Cantidad total de asistentes: " << cantidad<< endl;
}


