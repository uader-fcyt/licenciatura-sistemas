/*
 * Guia0-Eje7.cpp
 *
 *  Created on: 30 ago. 2017
 *      Author: chinosoliard
 *
 *  Un abuelo desea repartir el 2% de sus ingresos entre sus tres nietos en forma proporcional
 *  a la edad de ellos. Se ingresa el sueldo cobrado por el abuelo y las edades de sus nietos.
 *  Informar el total a repartir y lo que le corresponde a cada uno de los nietos.
 */

#include <iostream>
using namespace std;

float sueldo, porcentajeNieto1, porcentajeNieto2, porcentajeNieto3, mesadaNieto1, mesadaNieto2, mesadaNieto3;
int edadNieto1, edadNieto2, edadNieto3, sumaEdades;

int main(){
	cout << "Ingrese el sueldo del abuelo: ";
	cin >> sueldo;
	cout << "Ingrese la edad del primer nieto: ";
	cin >> edadNieto1;
	cout << "Ingrese la edad del segundo nieto: ";
	cin >> edadNieto2;
	cout << "Ingrese la edad del último nieto: ";
	cin >> edadNieto3;
	sumaEdades = edadNieto1 + edadNieto2 + edadNieto3;
	porcentajeNieto1 = (edadNieto1*100)/sumaEdades;
	porcentajeNieto2 = (edadNieto2*100)/sumaEdades;
	porcentajeNieto3 = (edadNieto3*100)/sumaEdades;
	mesadaNieto1 = sueldo * (porcentajeNieto1/100);
	mesadaNieto2 = sueldo * (porcentajeNieto2/100);
	mesadaNieto3 = sueldo * (porcentajeNieto3/100);
	cout << "Mesada para el primer nieto: " << mesadaNieto1 << endl;
	cout << "Mesada para el segundo nieto: " << mesadaNieto2 << endl;
	cout << "Mesada para el último nieto: " << mesadaNieto3 << endl;
}

