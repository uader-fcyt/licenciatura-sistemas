/*
 * Guia8-Eje09.cpp
 *
 *  Created on: 1 nov. 2017
 *      Author: chinosoliard
 *
 *  Una empresa posee N empleados y de cada uno de ellos los siguientes datos: Código de
 *  empleado (numérico), cantidad de horas normales trabajadas, cantidad de horas extras trabajadas.
 *  La cantidad de empleados y el valor de la hora normal de trabajo se leen como primeros datos
 *  Se pide:
 *  - Generar un archivo SUELDOS.TXT donde figure Cod de empleado, sueldo a cobrar.
 *  Tenga en cuenta que las horas extras se pagan el doble que las horas normales de trabajo.
 */

#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int cantEmpleados;
float valorHora;
int codigoEmpleado;
int cantidadHorasNormales;
int cantidadHorasExtras;
float sueldo;
ofstream archivo;

float calcularSueldo(float horasNormales, float horasExtras){
	float calculoSueldo = (horasNormales*valorHora)+(horasExtras*(valorHora*2));
	return calculoSueldo;
}

int main(){
	archivo.open("./SUELDOS.TXT");
	if(archivo.fail()){
		cout << "Error en el archivo" << endl;
		return 0;
	}
	cout << "Cantidad de empleados: ";
	cin >> cantEmpleados;
	cout << "Valor de la hora de trabajo: ";
	cin >> valorHora;

	for(int i = 0; i < cantEmpleados; i++){
		cout << "Ingrese el código del empleado: ";
		cin >> codigoEmpleado;
		cout << "Ingrese la cantidad de horas normales trabajadas: ";
		cin >> cantidadHorasNormales;
		cout << "Ingrese la cantidad de horas extras trabajadas: ";
		cin >> cantidadHorasExtras;
		sueldo = calcularSueldo(cantidadHorasNormales, cantidadHorasExtras);

		archivo << codigoEmpleado << endl;
		archivo << sueldo << endl;
	}

	archivo.close();

	return 0;
}
