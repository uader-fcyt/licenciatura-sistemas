/*
 * Guia3-Eje9.cpp
 *
 *  Created on: 3 oct. 2017
 *      Author: chinosoliard
 *
 *  Se desea generar una dirección de correo en base a la información ingresada por un
 *  estudiante. Se ingresa: nombre, apellido, fecha de nacimiento (DD/MM/AAAA) yfacultad.
 *  La dirección de correo se forma de la siguiente manera:
 *  Primer letra del nombre + Apellido + DDMM + “@” + facultad + “.edu.ar”
 */

#include <iostream>
#include <string>
using namespace std;

string nombre, apellido, fechaNac, facultad, email;

int main(){
	cout << "Ingrese nombre del alumno: ";
	getline(cin, nombre);
	cout << "Ingrese apellido del alumno: ";
	getline(cin, apellido);
	cout << "Ingrese fecha de nacimiento del alumno (DD/MM/AAAA): ";
	getline(cin, fechaNac);
	cout << "Ingrese el nombre de la facultad: ";
	getline(cin, facultad);
	//Primer letra del nombre + Apellido + DDMM + “@” + facultad + “.edu.ar”
	email = nombre[0]+apellido+fechaNac.substr(0, 2)+fechaNac.substr(3, 2)+"@"+facultad+".edu.ar";

	cout << "El correo es: " << email;
}
