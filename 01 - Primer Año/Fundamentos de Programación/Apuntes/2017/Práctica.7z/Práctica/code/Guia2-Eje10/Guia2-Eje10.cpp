/*
 * Guia2-Eje10.cpp
 *
 *  Created on: 1 oct. 2017
 *      Author: chinosoliard
 *
 * Una empresa paga a sus operarios semanalmente, de acuerdo con la cantidad de horas
 * trabajadas, a razón de x pesos la hora hasta 40 hs. y un 50% más por todas las horas
 * que pasan de 40. Para calcular el salario a un empleado, se ingresa el total de horas
 * trabajadas.
 * Informar salario a cobrar por el trabajador. El valor x se ingresa como primer dato.
 */

#include <iostream>
using namespace std;

int horasTrabajadas;
float valorHora, valorHoraExtra, total;

int main(){
	cout << "Ingrese el valor de la hora de trabajo: " ;
	cin >> valorHora;
	valorHoraExtra = valorHora*1.5;
	cout << "===========================================================" << endl;
	cout << "Ingrese la cantidad de horas trabajadas por el empleado: ";
	cin >> horasTrabajadas;
	if(horasTrabajadas > 40){
		total= (40*valorHora)+((horasTrabajadas-40)*valorHoraExtra);
	}
	else{
		total = horasTrabajadas * valorHora;
	}

	cout << "Total a cobrar por el trabajador: " << total << endl;
}



