/*
 * Guia2-Eje12.cpp
 *
 *  Created on: 1 oct. 2017
 *      Author: chinosoliard
 *
 *  Dado un valor de hora, donde se ingresan por separado horas (de 0 a 23), minutos y
 *  segundos. Informe la misma de la forma: hh:mm:ss am/pm (según corresponda).
 *  Ejemplos:
 *  1. 15:45:40 → 3:45:40 pm - 12:20:15 → 12:20:15 pm - 0:10:55 → 0:10:55 am
 */

#include <iostream>
using namespace std;

int hora, minuto, seg;

int main(){
	cout << "Ingrese hora (0/23): ";
	cin >> hora;
	cout << "Ingrese minutos: ";
	cin >> minuto;
	cout << "Ingrese segundos: ";
	cin >> seg;

	cout << "La hora en formato AM/PM es: ";
	if(hora >= 12){
		hora-=12;
		cout << hora << ":" << minuto << ":" << seg << " PM";
	}
	else{
		cout << hora << ":" << minuto << ":" << seg << " AM";
	}
	return 0;
}
