/*
 * Guia5-Eje02.cpp
 *
 *  Created on: 5 oct. 2017
 *      Author: chinosoliard
 *
 *  Generar un vector numérico de N elementos, para lo cual se ingresa por cada elemento:
 *  posición en el vector y valor a asignar. El valor N se ingresa como primer dato.
 */

#include <iostream>
using namespace std;

int main(){
	int N;
	cout << "Ingrese N:";
	cin >> N;
	int num[N];
	for(int i = 0;i<N;i++){
		int posicion, valor;
		cout << "ingrese posición (debe ser menor a " << N << "):";
		cin >> posicion;
		cout << "ingrese valor:";
		cin >> valor;
		num[posicion] = valor;
	}

	for (int i = 0; i<N;i++){
		cout << num[i]<< endl;
	}
}


