/*
 * Guia2E-Eje3.cpp
 *
 *  Created on: 2 oct. 2017
 *      Author: chinosoliard
 *
 *  Los docentes de la cátedra Programación desean contar con un programa que ingresada la
 *  nota de los 3 parciales rendidos por un alumno y los valores mínimos de promedios para
 *  promocionar y regularizar, determine la condición del alumno en la materia (Libre,
 *  Regular o Promocionado).
 *  Solo si promociona debe informar además la nota correspondiente para la libreta y el
 *  concepto para el acta de cierre. La Nota se obtiene aplicando la sig. fórmula:
 *  	Nota = Redondeo( (Promedio - A ) *6 / ( 100 – A ) + 4 )
 *  	A= límite para promoción
 *  Tenga en cuenta la siguiente tabla para determinar el concepto del alumno:
 *  	Nota		Concepto
 *  	4 ó 5		Aprobado
 *  	6 ó 7		Bueno
 *  	8 ó 9		Distinguido
 *  	10			Sobresaliente
 *  Observaciones: Las notas de los parciales y los valores mínimos son valores entre 0 y 100.
 */

#include <iostream>
#include <string>
#include <math.h>
using namespace std;

int promocion, regular, nota;
float parcial1, parcial2, parcial3, promedio;
string condicion, concepto;

int main(){
	cout << "Ingrese la nota del primer parcial: ";
	cin >> parcial1;
	cout << "Ingrese la nota del segundo parcial: ";
	cin >> parcial2;
	cout << "Ingrese la nota del tercer parcial: ";
	cin >> parcial3;
	cout << "Ingrese promedio promoción: ";
	cin >> promocion;
	cout << "Ingrese promedio regularización: ";
	cin >> regular;

	promedio = (parcial1 + parcial2 + parcial3) /3;

	if(promedio > promocion){
		condicion = "Promoción";
	}
	else if(promedio > regular){
		condicion = "Regular";
	}
	else{
		condicion = "Libre";
	}

	cout << "El alumno se encuentra en " << condicion << endl;
	if(condicion == "Promoción"){
		/*  	Nota = Redondeo( (Promedio - A ) *6 / ( 100 – A ) + 4 )
		  	A= límite para promoción */
		nota = round((promedio - promocion)*6/(100-promocion)+4);

		 /*  Tenga en cuenta la siguiente tabla para determinar el concepto del alumno:
		 *  	Nota		Concepto
		 *  	4 ó 5		Aprobado
		 *  	6 ó 7		Bueno
		 *  	8 ó 9		Distinguido
		 *  	10			Sobresaliente
		 *  Observaciones: Las notas de los parciales y los valores mínimos son valores entre 0 y 100. */

		if(nota == 4 || nota ==5){
			concepto = "Aprobado";
		}
		else if(nota == 6 || nota ==7){
			concepto = "Bueno";
		}
		else if(nota == 8 || nota ==8){
			concepto = "Distinguido";
		}
		else if(nota == 10){
			concepto = "Sobresaliente";
		}

		cout << "Nota para libreta: " << nota << endl;
		cout << "Concepto para acta de cierre: " << concepto << endl;
	}

	return 0;
}
