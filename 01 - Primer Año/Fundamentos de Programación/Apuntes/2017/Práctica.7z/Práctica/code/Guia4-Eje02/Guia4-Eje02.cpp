/*
 * Guia4-Eje02.cpp
 *
 *  Created on: 3 oct. 2017
 *      Author: chinosoliard
 *
 *  Queremos realizar un programa que lea por teclado dos números y muestre por pantalla
 *  su producto. Supondremos que no es posible utilizar el operador de multiplicación (*)
 *  directamente.
 */

#include <iostream>
using namespace std;

int contador = 0, producto, numero1, numero2;

int main(){
	cout << "Ingrese el primer número: ";
	cin >> numero1;
	cout << "Ingrese el segundo número: ";
	cin >> numero2;

	while(contador < numero2){
		producto+=numero1;
		contador++;
	}

	cout << "producto de " << numero1 << " por " << numero2 << " igual a: " <<  producto;
}


