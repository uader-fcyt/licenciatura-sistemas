/*
 * Guia4-Eje09.cpp
 *
 *  Created on: 3 oct. 2017
 *      Author: chinosoliard
 *
 *  Luego del examen parcial, se desean conocer los promedios obtenidos por cada comisión.
 *  Para ello, por cada comisión se conoce: el número de la misma y la cantidad de alumnos
 *  y, de cada uno de sus alumnos, la nota obtenida.
 *  Determinar e informar el promedio de cada comisión y el promedio total. Los datos finalizan
 *  con número de comisión = 999.
 */

#include <iostream>
using namespace std;

int aux, contador, contadorGeneral, numeroComision, cantidadAlumnos, sumaComision, sumaTotal, promedioComision, promedioTotal;
string detalle, listaCompleta;

int main(){
	cout << "Ingrese el número de la comisión: ";
	cin >> numeroComision;

	while(numeroComision != 999){
		detalle = "\n Comisión ";
		detalle = detalle + to_string(numeroComision) + "		";
		cout << "Cantidad de alumnos: ";
		cin >> cantidadAlumnos;
		detalle = detalle + "Alumnos: ";
		detalle = detalle + to_string(cantidadAlumnos) + "		";
		contador = 0;
		sumaComision = 0;
		while(contador < cantidadAlumnos){
			contadorGeneral++;
			contador++;
			cout << "nota del alumno nº " << contador << ":";
			cin >> aux;
			sumaComision+=aux;
			sumaTotal+=aux;
		}
		promedioComision = sumaComision/contador;
		detalle = detalle + "Promedio: ";
		detalle = detalle + to_string(promedioComision);
		listaCompleta = listaCompleta + detalle;

		cout << "Ingrese el número de la comisión: ";
		cin >> numeroComision;
	}
	promedioTotal = sumaTotal/contadorGeneral;
	cout << listaCompleta << "\n";

	cout << "Promedio total: " << promedioTotal;
}
