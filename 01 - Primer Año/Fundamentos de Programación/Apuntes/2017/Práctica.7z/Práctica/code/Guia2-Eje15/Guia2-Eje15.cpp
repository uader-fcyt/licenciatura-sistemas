/*
 * Guia2-Eje15.cpp
 *
 *  Created on: 2 oct. 2017
 *      Author: chinosoliard
 *
 *  Una inmobiliaria que alquila departamentos ha divido la ciudad en tres zonas:
 *  	1 - centro
 *  	2 - residencial
 *  	3 - barrio
 *  El importe mensual a pagar por el inquilino corresponde al precio base del departamento
 *  más el importe correspondiente a impuestos y comisiones, los cuales dependen de la zona
 *  de ubicación del inmueble, de acuerdo a las siguientes pautas:
 *  	Zona		Impuestos y comisiones
 *  	1			15% sobre el precio del alquiler
 *  	2			10% “
 *  	3			8 % “
 *  Se desea calcular el monto total del alquiler de un departamento y para ello se ingresa
 *  el precio del alquiler y la zona donde se encuentra la vivienda (1, 2 ó 3).
 *  Informar el precio base del alquiler, el monto de impuestos y comisiones y el total a
 *  pagar por el inquilino con leyendas indicativas.
 */

#include <iostream>
#include <string>
using namespace std;

int precioAlquiler, zona;
float montoImpComi, totalAlquiler;
string zonaString;

int main(){
	cout << "Ingrese el precio del alquiler: ";
	cin >> precioAlquiler;
	cout << "Ingrese la zona del departamento: ";
	cin >> zona;
	switch(zona){
	case 1:{
		zonaString = "Centro";
		montoImpComi = precioAlquiler * 0.15;
		break;
	}
	case 2:{
		zonaString = "Residencial";
		montoImpComi = precioAlquiler * 0.10;
		break;
	}
	case 3:{
		zonaString = "Barrio";
		montoImpComi = precioAlquiler * 0.08;
		break;
	}
	default:{break;}
	}
	totalAlquiler = precioAlquiler + montoImpComi;

	cout << "=======================================" << endl;
	cout << "Precio alquiler: " << precioAlquiler << endl;
	cout << "Zona alquiler: " << zonaString << endl;
	cout << "Impuestos y comisiones: " << montoImpComi << endl;
	cout << "Total a pagar: " << totalAlquiler << endl;
}



