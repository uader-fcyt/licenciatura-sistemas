/*
 * Guia1-Eje6.cpp
 *
 *  Created on: 4 sep. 2017
 *      Author: chinosoliard
 *
 *  Una remisera desea liquidar el sueldo de los choferes de una de sus unidades para ello
 *  se ingresan los datos de los 2 choferes de la misma: nombre y apellido, sueldo básico
 *  y km. recorridos en el mes a liquidar. Primero se ingresan los datos del chofer 1, y
 *  luego los datos del chofer 2. Se desea generar un informe como el siguiente:
 *  LIQUIDACION MENSUAL CHOFERES
 *  NOMBRE DEL CHOFER 1.............................. TOTAL A COBRAR $..................
 *  NOMBRE DEL CHOFER 2.............................. TOTAL A COBRAR $..................
 *  TOTAL GRAL $......................
 *
 *  Observación: Tener en cuenta que por cada km. se le paga $12,5 y que el total a cobrar
 *  se calcula como: Sueldo básico + monto por kms.
 */

#include <iostream>
using namespace std;
#include <string>
using namespace std;

string nombreChofer1, nombreChofer2;
float sueldoBasico, totalChofer1, totalChofer2;
int kmsRecorridosChofer1, kmsRecorridosChofer2;

int main(){
	cout << "Ingrese sueldo básico: ";
	cin >> sueldoBasico;
	cin.get();
	cout << "Ingrese el nombre del chofer 1: ";
	getline(cin, nombreChofer1);
	cout << "Ingrese la cantidad de kilometros recorridos por el chofer 1: ";
	cin >> kmsRecorridosChofer1;
	cin.get();
	cout << "Ingrese el nombre del chofer 2: ";
	getline(cin, nombreChofer2);
	cout << "Ingrese la cantidad de kilometros recorridos por el chofer 2: ";
	cin >> kmsRecorridosChofer2;
	cin.get();
	totalChofer1 = sueldoBasico + (kmsRecorridosChofer1*12.5);
	totalChofer2 = sueldoBasico + (kmsRecorridosChofer2*12.5);
	cout << "LIQUIDACION MENSUAL CHOFERES"<< endl;
	cout << "NOMBRE DEL CHOFER 1 = " << nombreChofer1 << "	TOTAL A COBRAR $ " << totalChofer1 << endl;
	cout << "NOMBRE DEL CHOFER 2 =i " << nombreChofer2 << "	TOTAL A COBRAR $ " << totalChofer2 << endl;
	cout << "TOTAL GRAL $ " << (totalChofer1 + totalChofer2);
	return 0;
}



