/*
 * Guia3-Eje8.cpp
 *
 *  Created on: 3 oct. 2017
 *      Author: chinosoliard
 *
 *  Ingrese una cadena de caracteres e informe la segunda palabra de la misma.
 */

#include <iostream>
#include <string>
using namespace std;

string cadena, segundaPalabra;

int main(){
	cout << "Ingrese una cadena de texto: " << endl;
	getline(cin, cadena);

	segundaPalabra = cadena.substr((cadena.find(" ")+1), cadena.find(" ", (cadena.find(" ")-1)));

	cout << segundaPalabra;
}

