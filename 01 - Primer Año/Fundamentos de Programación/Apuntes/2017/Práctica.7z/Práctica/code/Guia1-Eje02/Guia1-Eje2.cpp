/*
 * Guia1-Eje2.cpp
 *
 *  Created on: 4 sep. 2017
 *      Author: chinosoliard
 *
 *  Determine la edad de una persona (sin importar si ya ha cumplido años o aún no),
 *  conociendo su año de nacimiento.
 */

#include <iostream>
using namespace std;

int ANIOACTUAL = 2017;

int anioNacimiento, edad;

int main(){
	cout << "Ingrese el año de nacimiento de la persona: ";
	cin >> anioNacimiento;
	edad = ANIOACTUAL - anioNacimiento;
	cout << "La edad de la persona es: " << edad;
	return 0;
}


