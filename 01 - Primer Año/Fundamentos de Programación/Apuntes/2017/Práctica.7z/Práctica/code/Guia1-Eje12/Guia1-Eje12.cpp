/*
 * Guia1-Eje12.cpp
 *
 *  Created on: 8 sep. 2017
 *      Author: chinosoliard
 *
 *  ¿Cuánto dinero hay en una Caja de Seguridad?
 *  Para ello se ingresa la cantidad de billetes que hay de $5, $10, $20, $50 y $100
 *  respectivamente. Informar el total existente.
 */

#include <iostream>
using namespace std;

int cant5, cant10, cant20, cant50, cant100, total;

int main(){
	cout << "Ingrese la cantidad de billetes de $5: ";
	cin >> cant5;
	cout << "Ingrese la cantidad de billetes de $10: ";
	cin >> cant10;
	cout << "Ingrese la cantidad de billetes de $20: ";
	cin >> cant20;
	cout << "Ingrese la cantidad de billetes de $50: ";
	cin >> cant50;
	cout << "Ingrese la cantidad de billetes de $100: ";
	cin >> cant100;
	total = (cant5*5)+(cant10*10)+(cant20*20)+(cant50*50)+(cant100*100);
	cout << "En la caja de seguridad hay " << total << " pesos" << endl;
	return 0;
}


