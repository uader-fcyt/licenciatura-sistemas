/*
 * Guia4-Eje10.cpp
 *
 *  Created on: 3 oct. 2017
 *      Author: chinosoliard
 *
 *  Escriba un programa que solicite números al usuario hasta que se hayan introducido 10
 *  números o la suma de todos los números leídos sea mayor que 100. A continuación mostrar
 *  un mensaje indicando qué condición se ha cumplido (es decir, si se han introducido 10
 *  números o si su suma es mayor que 100).
 */

#include <iostream>
using namespace std;

int suma, cantidad, numero;

int main(){
	while((suma < 100) || cantidad < 10){
		cout << "Ingrese un número: ";
		cin >> numero;
		cantidad++;
		suma+=suma;
	}

	if(cantidad == 10){
		cout << "Se llegó a los 10 ingresos" << endl;
	}
	else if (suma == 100){
		cout << "La suma de los ingresos llegó a 100";
	}
}
