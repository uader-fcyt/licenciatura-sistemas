/*
 * Guia3-Eje4.cpp
 *
 *  Created on: 2 oct. 2017
 *      Author: chinosoliard
 *
 *  Ingrese 2 cadenas de caracteres y un valor entero X. Inserte la segunda cadena dentro
 *  de la primera a partir de la pósición X, salvo que dicha posición sea inválida.
 */

#include <iostream>
#include <string>
using namespace std;

string cadena1, cadena2;
int x, n;

int main(){
	cout << "Ingrese la primera: " << endl;
	getline(cin, cadena1);
	cout << "Ingrese la segunda: " << endl;
	getline(cin, cadena2);
	cout << "Ingrese un entero x: ";
	cin >> x;

	n = cadena1.size();
	if(n > x){
		cadena1.insert(x, cadena2);
		cout << cadena1;
	}
	else{ cout << "no se puede";}

}

