/*
 * Guia0-Eje5.cpp
 *
 *  Created on: 30 ago. 2017
 *      Author: chinosoliard
 *
 *  Se desea obtener la cuota a pagar por un crédito solicitado.
 *  Se ingresa la información de:
 *  Capital solicitado, Razón (tasa anual), plazo (en meses).
 *  El cálculo de interés simple se realiza con la fórmula:
 *  (Capital x razón x tiempo) / (100 x 12).
 *  El monto que se obtenga (capital + interés) dividido el plazo da como resultado el valor
 *  de la cuota.
 */

#include <iostream>
using namespace std;

float capitalSolicitado, razon, interesSimple, valorCuota;
int plazo;

int main(){
	cout << "Ingrese el capital solicitado: ";
	cin >> capitalSolicitado;
	cout << "Ingrese la razón (tasa anual): ";
	cin >> razon;
	cout << "Ingrese el plazo (en meses): ";
	cin >> plazo;
	interesSimple = (capitalSolicitado*razon*plazo) / (100/12);
	valorCuota = (capitalSolicitado + interesSimple) / plazo;
	cout << "El monto de la cuota es: " << valorCuota;
}

