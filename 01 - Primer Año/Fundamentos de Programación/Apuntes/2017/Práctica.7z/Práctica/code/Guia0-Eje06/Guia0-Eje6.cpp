/*
 * Guia0-Eje6.cpp
 *
 *  Created on: 30 ago. 2017
 *      Author: chinosoliard
 *
 *  Una alumno ha rendido 2 exámenes parciales y ha presentado un trabajo práctico.
 *  Según las calificaciones obtenidas, se determina la calificación del alumno:
 *  El promedio de los parciales constituye el 80% de la calificación final, el 20%
 *  restante es la correspondiente al trabajo práctico. Tanto los parciales como el trabajo
 *  práctico son calificados entre 0 y 100.
 *  Se ingresan las 3 notas obtenidas. Informar la nota final.
 */

#include <iostream>
using namespace std;

int parcial1, parcial2, trabajoPractico;
float notaFinal;

int main(){
	cout << "Ingrese la nota del primer parcial: ";
	cin >> parcial1;
	cout << "Ingrese la nota del segundo parcial: ";
	cin >> parcial2;
	cout << "Ingrese la nota del trabajo práctico: ";
	cin >> trabajoPractico;
	notaFinal = (((parcial1+parcial2)*80)/200)+((trabajoPractico*20)/100);
	cout << "La nota final del alumno es: " << notaFinal;
}
