#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <iomanip>
using namespace std;
/*Tome el archivo generado en el ejercicio anterior, paselo a una matriz de 2 columnas y ordene la
	matriz por la columna donde esten los valores de y.*/
int main(int argc, char *argv[]) {
	ifstream archivo;

	archivo.open("../gamarra1/variables.TXT");
	if(archivo.fail()){
		cout<<"archivo no encontrado"<<endl;
	}

	int i=0, j =0,contador=0;
	int matriz[10][2];
	string linea;

	while(!archivo.eof())
	{
		getline(archivo,linea);
		matriz[i][0] = atoi(linea.c_str());
		getline(archivo,linea);
		matriz[i][1] = atoi(linea.c_str());
		contador=i;
		i++;
	}
	for(i=0;i<contador;i++){

		 cout<<matriz[i][0]<<"     "<<matriz[i][1]<<endl;

	}

	system("pause");
	return 0;
}
