/*
 * Guia3-Eje6.cpp
 *
 *  Created on: 3 oct. 2017
 *      Author: chinosoliard
 *
 *  Ingrese una cadena de caracteres e informe si la misma tiene más de una palabra,
 *  la letra con la que empieza y la letra con la que termina.
 */

#include <iostream>
#include <string>
using namespace std;

string cadena;

int main(){
	cout << "Ingrese una cadena de texto: ";
	getline(cin, cadena);
	if(cadena.find(" ") == true){
		cout << "La cadena tiene más de una palabra" << endl;
	}

	cout << "La cadena comienza con la letra " << cadena[0] << endl;

	cout << "La cadena termina con la letra " << cadena[(cadena.size())-1];
}


