/*
 * Guia2-Eje4.cpp
 *
 *  Created on: 30 sep. 2017
 *      Author: chinosoliard
 *
 *  Utilice las variables x, y, z, u definidas en el
 *  ejercicio anterior, para calcular las siguientes
 *  expresiones matemáticas
 *
 *  float x = 4.5, y = 12.3;
 *  int z = 10, u = 8;
 *
 *  a) u/2
 *  b) (x-y)/2+abs(u-y)
 *  c) 3 + u % 3
 *  d) u * 2
 *  e) 2*u+x/3
 *  f) pow(z,3)
 *  g) x = (x+1) / 2
 *  h) u/2.0
 *  i) y /= z
 */


#include <iostream>
#include <math.h>
using namespace std;

float x = 4.5, y = 12.3;
int z = 10, u = 8;
float aux;

int main(){
	aux = u/2;
	cout << "a) u/2: " << aux << endl;
	aux = (x-y)/2+abs(u-y);
	cout << "b) (x-y)/2+abs(u-y): " << aux << endl;
	aux = 3 + u % 3;
	cout << "c) 3 + u % 3: " << aux << endl;
	aux = u * 2;
	cout << "d) u * 2: " << aux << endl;
	aux = 2*u+x/3;
	cout << "e) 2*u+x/3: " << aux << endl;
	aux = pow(z,3);
	cout << "f) pow(z,3): " << aux << endl;
	aux = x = (x+1) / 2;
	cout << "g) x = (x+1) / 2: " << aux << endl;
	aux = u/2.0;
	cout << "h) u/2.0: " << aux << endl;
	aux = y /= z;
	cout << "i) y /= z: " << aux << endl;
	return 0;
}
