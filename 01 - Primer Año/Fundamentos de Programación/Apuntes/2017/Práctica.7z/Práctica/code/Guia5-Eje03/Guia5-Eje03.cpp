/*
 * Guia5-Eje03.cpp
 *
 *  Created on: 5 oct. 2017
 *      Author: chinosoliard
 *
 *  Dado un vector numérico de dimensión J escribir un mensaje indicando si el promedio de
 *  los elementos ubicados en posición par es mayor que el promedio de los elementos ubicados
 *  en posición impar. El valor J se ingresa como primer dato.
 */

#include <iostream>
using namespace std;

int main(){
	int J;
	cout << "Ingrese J: ";
	cin >> J;
	int num[J];
	int promedioPar = 0, promedioImpar = 0, cantidadPar = 0, cantidadImpar = 0, sumaPar = 0, sumaImpar = 0;
	for(int i = 0; i < J; i++){
		num[i] = rand() % 100;
	}

	for(int i = 0; i < J; i++){
		if((i+1)%2 == 0){
			cantidadPar++;
			sumaPar+=num[i];
		}
		else{
			cantidadImpar++;
			sumaImpar+=num[i];
		}
	}

	promedioPar = sumaPar/cantidadPar;
	promedioImpar = sumaImpar/ cantidadImpar;

	if(promedioPar > promedioImpar){
		cout << "El promedio de los números ubicados en posición PAR es mayor";
	}
	else{
		cout << "El promedio de los números ubicados en posición IMPAR es mayor";
	}
}



