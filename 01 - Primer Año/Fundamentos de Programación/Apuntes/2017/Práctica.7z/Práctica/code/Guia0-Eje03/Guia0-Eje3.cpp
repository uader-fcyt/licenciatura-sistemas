/*
 * Guia0-Eje3.cpp
 *
 *  Created on: 30 ago. 2017
 *      Author: chinosoliard
 *
 *  Se desea contar con una aplicación que calcule el ancho de un televisor teniendo como
 *  dato la cantidad de pulgadas del TV y el alto de la pantalla (expresado en cm).
 *  Informar el ancho del TV expresado en cm.
 */

#include <iostream>
using namespace std;
#include <math.h>
using namespace std;

float anchoTVcm, pulgadasTV, pulgadasTVcm, altoTVcm;

int main(){
	cout << "ingrese las pulgadas del TV: ";
	cin >> pulgadasTV;
	cout << "ingrese el alto (en cms) del TV: ";
	cin >> altoTVcm;
	pulgadasTVcm = pulgadasTV*2.54;
	anchoTVcm = sqrt((pow(altoTVcm,2))+(pow(pulgadasTVcm,2)));
	cout << "El TV tiene un ancho de " << anchoTVcm << "cms" << endl;
}


