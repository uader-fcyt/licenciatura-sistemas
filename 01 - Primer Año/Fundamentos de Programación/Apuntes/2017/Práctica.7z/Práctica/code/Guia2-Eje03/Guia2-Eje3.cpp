/*
 * Guia2-Eje3.cpp
 *
 *  Created on: 13 sep. 2017
 *      Author: chinosoliard
 *
 *  Considere las declaraciones de un programa C++, donde se definen las variables x, y, z, u
 *  como se indica abajo:
 *  float x = 4.5, y = 12.3;
 *  int z = 10, u = 8;
 *  char letra = ‘m’;
 *
 *  Determine el resultado de las siguientes expresiones lógicas:
 *  a) x < y
 *  b) (x <= y) || (letra == 'j')
 *  c) letra <= 'G'
 *  d) abs(x-y) > 0
 *  e) u++ >= z-- && 1
 *  f) (z>x)&&(letra<'m')||(letra=='h')
 *  g) '2' <= letra
 *  h) ('q' < 's') || false
 *  i) sin(y-x) <= 1
 *  j) toupper(letra) == ‘M’
 */

#include <iostream>
#include <math.h>
using namespace std;

float x = 4.5, y = 12.3;
int z = 10, u = 8;
char letra = 'm';
int aux;

int main(){
	aux = x<y;
	cout << "a) x < y: " << aux << endl;
	aux = (x < y) || (letra == 'j');
	cout << "b) (x <= y) || (letra == 'j'): " << aux << endl;
	aux = letra <= 'G';
	cout << "c) letra <= 'G': " << aux << endl;
	aux = abs(x-y) > 0;
	cout << "d) abs(x-y) > 0: " << aux << endl;
	aux = u++ >= z-- && 1;
	cout << "e) u++ >= z-- && 1: " << aux << endl;
	aux = ((z>x) && (letra < 'm')) || (letra == 'h');
	cout << "f) (z>x)&&(letra<'m')||(letra=='h'): " << aux << endl;
	aux = '2' <= letra;
	cout << "g) '2' <= letra; " << aux << endl;
	aux = ('q' < 's') || false;
	cout << "h) ('q' < 's') || false: " << aux << endl;
	aux = sin(y-x) <= 1;
	cout << "i) sin(y-x) <= 1: " << aux << endl;
	aux = toupper(letra) == 'M';
	cout << "j) toupper(letra) == ‘M’: " << aux << endl;
	return 0;
}
