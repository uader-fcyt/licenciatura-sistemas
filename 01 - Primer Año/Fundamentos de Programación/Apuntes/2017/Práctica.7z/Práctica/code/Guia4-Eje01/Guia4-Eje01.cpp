/*
 * Guia4-Eje01.cpp
 *
 *  Created on: 3 oct. 2017
 *      Author: chinosoliard
 *
 *  Realice un algoritmo que informe los múltiplos de 4 menores que 200 (sin incluir este
 *  último).
 */

#include <iostream>
using namespace std;

int numero;

int main(){
	while(numero <200){
		if((numero%4) ==0){
			cout << numero << endl;
		}
		numero++;
	}
}



