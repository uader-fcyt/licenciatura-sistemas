/*
 * Guia1-Eje5.cpp
 *
 *  Created on: 4 sep. 2017
 *      Author: chinosoliard
 *
 *  En un recital se vendieron dos tipos de entradas, a saber: popular y platea. El éxito
 *  del recital se ocasionó porque se lograron vender la totalidad de las plateas y de las
 *  populares, 1000 y 3000 respectivamente. El precio de la popular fue un 50 % más barato
 *  que el de la platea. Hallar la recaudación total del recital, sabiendo que se ingresa
 *  como primer dato el precio de la platea.
 */

#include <iostream>
using namespace std;

float precioPlatea, precioPopular, totalRecaudado;

int main(){
	cout << "Ingrese el precio de la Platea:";
	cin >> precioPlatea;
	precioPopular = precioPlatea *0.5;
	totalRecaudado = (precioPlatea*1000)+(precioPopular*3000);
	cout << "El total recaudado fue: $" << totalRecaudado;
	return 0;
}


