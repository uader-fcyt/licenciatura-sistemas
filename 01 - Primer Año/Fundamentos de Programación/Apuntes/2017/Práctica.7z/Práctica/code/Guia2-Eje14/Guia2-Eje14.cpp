/*
 * Guia2-Eje14.cpp
 *
 *  Created on: 2 oct. 2017
 *      Author: chinosoliard
 *
 *  Un club cobra una cuota mensual a sus socios, a quienes divide en Activo, Familiar y Cadete.
 *  El socio activo paga el valor base, el familiar un 50 % más y el cadete paga un 20% menos.
 *  Se ingresa como primer dato el valor base de la cuota.
 *  Además se ingresa el nombre del club y los datos de un socio: número de socio, nombre y
 *  apellido y tipo ( ́activo ́,  ́familiar ́,  ́cadete ́).
 *  Informar lo que debe pagar el socio ingresado, con el siguiente formato:
 *  CLUB:................................
 *  NRO. DE SOCIO:.......................... NOMBRE DEL SOCIO:...................................
 *  TIPO DE SOCIO:........................... TOTAL APAGAR: $.....................
 */

#include <iostream>
#include <string>
using namespace std;

float valorActivo, valorFamiliar, valorCadete, totalPagar;
string nombreClub, nombreApellido, tipoSocioString;
int numeroSocio, tipoSocio;

int main(){
	cout << "Ingrese el valor base de la cuota: ";
	cin >> valorActivo;
	valorFamiliar = valorActivo * 1.5;
	valorCadete = valorActivo * 0.8;
	cout << "Ingrese el nombre del club: " << endl;
	cin.get();
	getline(cin, nombreClub);
	cout << "Ingrese el número de socio: " << endl;
	cin >> numeroSocio;
	cout << "Ingrese nombre y apellido del socio: " << endl;
	cin.get();
	getline(cin, nombreApellido);
	cout << "Ingrese el tipo de socio (1: activo - 2: familiar - 3: cadete): ";
	cin >> tipoSocio;
	switch(tipoSocio){
	case 1:{
		tipoSocioString = "Activo";
		totalPagar = valorActivo;
		break;
	}
	case 2:{
		tipoSocioString = "Familiar";
		totalPagar = valorFamiliar;
		break;
	}
	case 3:{
		tipoSocioString = "Cadete";
		totalPagar = valorCadete;
		break;
	}
	default:{ break; }
	}

	cout << "===========================================================================" << endl;
	cout << "CLUB: "<< nombreClub << endl;
	cout << "NRO. DE SOCIO: " << numeroSocio << "		NOMBRE DEL SOCIO: " << nombreApellido << endl;
	cout << "TIPO DE SOCIO: " << tipoSocioString << "		TOTAL A PAGAR: " << totalPagar << endl;
}


