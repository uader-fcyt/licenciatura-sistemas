/*
 * Guia4-Eje05.cpp
 *
 *  Created on: 3 oct. 2017
 *      Author: chinosoliard
 *
 *  Se ingresan dos números, luego multiplicar todos los números que van desde el primero
 *  al segundo. Se debe verificar que los valores son correctos. Ej.: Ingreso: 3 y 9.
 *  Multiplicar 3x3, 3x4,....3x9. Mostrar cada resultado obtenido
 */

#include <iostream>
using namespace std;

int numero1, numero2, multiplo, aux;

int main(){
	cout << "Ingrese el primer número: ";
	cin >> numero1;
	cout << "Ingrese el segundo número: ";
	cin >> numero2;

	multiplo = numero1;
	while(multiplo <= numero2){
		aux = numero1 * multiplo;
		cout << numero1 << " * " << multiplo << " = " << aux << endl;
		multiplo++;
	}
}


