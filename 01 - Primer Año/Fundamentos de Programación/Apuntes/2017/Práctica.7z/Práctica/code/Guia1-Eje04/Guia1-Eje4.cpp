/*
 * Guia1-Eje4.cpp
 *
 *  Created on: 4 sep. 2017
 *      Author: chinosoliard
 *  Una persona ha efectuado una compra en un negocio. Al momento de pagar, le comunican
 *  que cuenta con un 20% de descuento. Determinar el total a pagar, conociendo el monto
 *  sin descuento. Informar según el siguiente detalle:
 *  TOTAL COMPRA : $ XXXXX
 *  DESCUENTO : $ XXX
 *  TOTAL A PAGAR : $ XXX
 */

#include <iostream>
using namespace std;

float subtotal, descuento, total;

int main(){
	cout << "Ingrese el subtotal: ";
	cin >> subtotal;
	descuento = subtotal * 0.2;
	total = subtotal - descuento;
	cout << "TOTAL COMPRA : $" << subtotal << endl;
	cout << "DESCUENTO : $" << descuento << endl;
	cout << "TOTAL A PAGAR : $" << total;
	return 0;
}

