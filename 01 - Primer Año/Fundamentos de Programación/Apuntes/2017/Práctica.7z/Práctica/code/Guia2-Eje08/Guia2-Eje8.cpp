/*
 * Guia2-Eje8.cpp
 *
 *  Created on: 1 oct. 2017
 *      Author: chinosoliard
 *
 *  Se desea saber si un estudiante de primer año de la Facultad, vota en las
 *  próximas elecciones, para lo cual, debe ser mayor de 18 años. Se ingresan
 *  la fecha de nacimiento y la fecha de votación con formato día, mes y año
 *  (ddmmaaa). Informe con un mensaje alusivo.
 */

#include <iostream>
using namespace std;

int fechaNacimientoCompleta, fechaVotacionCompleta, diaNac, mesNac, anioNac, diaVot, mesVot, anioVot;

int main(){
	cout << "Ingrese la fecha de nacimiento del alumno (formato ddmmaaaa): ";
	cin >> fechaNacimientoCompleta;
	cout << "Ingrese la fecha de votación (formato ddmmaaaa): ";
	cin >> fechaVotacionCompleta;

	diaNac = fechaNacimientoCompleta/1000000;
	mesNac = (fechaNacimientoCompleta-(diaNac*1000000))/10000;
	anioNac = fechaNacimientoCompleta-(diaNac*1000000)-(mesNac*10000);

	diaVot = fechaVotacionCompleta/1000000;
	mesVot = (fechaVotacionCompleta-(diaVot*1000000))/10000;
	anioVot = fechaVotacionCompleta-(diaVot*1000000)-(mesVot*10000);

	if(anioVot-anioNac < 18){
		cout << "El alumno NO VOTA";
	}
	else if (anioVot - anioNac > 18){
		cout << "El alumno VOTA";
	}
	else if ((anioVot - anioNac == 18) && ((mesVot - mesNac >= 0) && (diaVot - diaNac >= 0))){
		cout << "El alumno VOTA";
	}
	else{
		cout << "El alumno NO VOTA";
	}

	return 0;
}


