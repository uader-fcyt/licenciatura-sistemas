/*
 * Guia8-Eje11.cpp
 *
 *  Created on: 1 nov. 2017
 *      Author: chinosoliard
 *
 *  11. Se dispone del archivo PRODUCTOS_EN_DOLARES.TXT que tiene la información: cod de producto,
 *  descripción y precio em dolares (provisto por la cátedra).
 *  Se solicita generar un archivo PRODUCTOS_EN_PESOS.TXT que tenga la misma estructura que el
 *  archivo anterior pero com el precio transformado a pesos.
 *  La cotización del dólar se ingresa al principio.
 */

#include <iostream>
#include <string>
#include <fstream>
using namespace std;

float cotizacion = 17.7;
string codigoProducto;
string descripcionProducto;
string precioDolares;
float precioPesos;
ifstream archivoDolares; //abrir
ofstream archivoPesos; //guardar

float dolarAPesos(float dolar){
	float valorPesos = dolar*cotizacion;
	return valorPesos;
}

int main(){
	archivoDolares.open("./PRODUCTOS_EN_DOLARES.txt");
	if(archivoDolares.fail()){
		cout << "Error al leer el archivo de entrada" << endl;
		return 0;
	}
	if(archivoPesos.fail()){
		cout << "Error al abrir el archivo de salida" << endl;
		return 0;
	}
	archivoPesos.open("./PRODUCTOS_EN_PESOS.txt");
	getline(archivoDolares, codigoProducto);
	while(!archivoDolares.eof()){
		cout << "Código producto: " << codigoProducto << endl;
		getline(archivoDolares, descripcionProducto);
		cout << "Descripción producto: " << descripcionProducto << endl;
		getline(archivoDolares, precioDolares);
		cout << "Precio en dolares: " << precioDolares << endl;
		precioPesos = dolarAPesos(atof(precioDolares.c_str()));
		cout << "Precio en pesos: " << precioPesos << endl;
		archivoPesos << codigoProducto << endl;
		archivoPesos << descripcionProducto << endl;
		archivoPesos << precioPesos << endl;
		getline(archivoDolares, codigoProducto);
	}

	archivoPesos.close();
	archivoDolares.close();

	return 0;
}




