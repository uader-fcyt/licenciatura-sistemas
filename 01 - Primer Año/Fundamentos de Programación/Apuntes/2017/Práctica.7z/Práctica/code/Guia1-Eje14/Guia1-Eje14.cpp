/*
 * Guia1-Eje14.cpp
 *
 *  Created on: 8 sep. 2017
 *      Author: chinosoliard
 *
 *  2 puestos de la policía caminera situados en cada uno de los extremos de un pueblo,
 *  comparten información relativa a los autos que circulan por la ruta que lo atraviesa.
 *  Por cada auto reciben la siguiente información: patente, hora, minutos y segundos del
 *  paso por el primer puesto, hora,minutos y segundos del paso por el segundo puesto.
 *  Se sabe que los puestos están separados por 7 1/2 kilómetros. Se desea generar un
 *  algoritmo que informe la patente y la velocidad promedio a la que circuló el auto por
 *  el pueblo.
 */

#include <iostream>
#include <string.h>
using namespace std;

int hora1, hora2, velocidadPromedio, tiempoPasada;
string patente;

int main(){
	cout << "Ingrese la patente del vehículo: ";
	cin.get();
	getline(cin, patente);
	cout << "Ingrese la hora exacta en la que pasó por el primer puesto (en formato hhmmss): ";
	cin >> hora1;
	cout << "Ingrese la hora exacta en la que pasó por el segundo puesto (en formato hhmmss): ";
	cin >> hora2;
	tiempoPasada = hora2 - hora1;


}
