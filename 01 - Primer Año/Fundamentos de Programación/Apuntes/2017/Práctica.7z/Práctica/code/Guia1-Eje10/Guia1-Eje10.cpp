/*
 * Guia1-Eje10.cpp
 *
 *  Created on: 7 sep. 2017
 *      Author: chinosoliard
 *
 *  Se desea que dada una fecha ingresada de la forma MMDDAA, se la informe de la forma
 *  DD/MM/AAAA
 */

#include <iostream>
using namespace std;

int fechaOriginal, mes, dia, anio;

int main(){
	cout << "Ingrese una fecha en formato MMDDAA: ";
	cin >> fechaOriginal;
	mes = fechaOriginal/10000;
	dia = (fechaOriginal -(mes*10000))/100;
	anio = (fechaOriginal-(mes*10000)-(dia*100))+2000;

	cout << "Fecha en formato DD/MM/AAAA: " << dia << "/" << mes << "/" << anio << endl;


	return 0;
}


