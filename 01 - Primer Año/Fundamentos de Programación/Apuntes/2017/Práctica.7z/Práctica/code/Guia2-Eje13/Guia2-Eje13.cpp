/*
 * Guia2-Eje13.cpp
 *
 *  Created on: 2 oct. 2017
 *      Author: chinosoliard
 *
 *  Una empresa desea calcular el sueldo de un empleado sabiendo que el sueldo básico
 *  depende de la categoría. Además, se le paga un adicional por antigüedad.
 *  La determinación del básico se realiza según el siguiente detalle:
 *  Categoría		Sueldo Básico
 *  	1			$ 2500
 *  	2			$ 2000
 *  	3			$ 1500
 *  	4			$ 1200
 *
 *  La antigüedad se calcula en base a la siguiente tabla:
 *  Antigüedad		Porcentaje
 *  0-10 años		20%
 *  11-15 años		50%
 *  16-20 años		80 %
 *  más de 20 años	100%
 *
 *  Para ello se ingresan los datos de un empleado en el siguiente orden:
 *  Apellido y nombre, categoría (1 a 4) y antigüedad.
 *
 *  Informar con el siguiente formato:
 *  APELLIDO Y NOMBRE : .........................................................
 *  CATEGORÍA : ...... 						SUELDO BÁSICO : $ .....................
 *  ANTIGÜEDAD : ........ AÑOS				MONTO ANTIGÜEDAD : $................
 *  SUELDO TOTAL : $ ................................
 */

#include <iostream>
#include <string>
using namespace std;

const int CATEGORIA1 = 2500;
const int CATEGORIA2 = 2000;
const int CATEGORIA3 = 1500;
const int CATEGORIA4 = 1200;

string empleado;
int categoria, antiguedad;
float sueldoBasico, montoAntiguedad, sueldoTotal;

int main(){
	cout << "Apellido y Nombre del empleado: " << endl;
	getline(cin, empleado);
	cout << "Categoría del empleado: ";
	cin >> categoria;
	cout << "Antigüedad del empleado: ";
	cin >> antiguedad;

	switch(categoria){
		case 1:{
			sueldoBasico = CATEGORIA1;
			if(antiguedad <=10){
				montoAntiguedad = CATEGORIA1*0.2;
			}
			else if(antiguedad >=11 && antiguedad <=15){
				montoAntiguedad = CATEGORIA1*0.5;
			}
			else if(antiguedad >=16 && antiguedad <=20){
				montoAntiguedad = CATEGORIA1*0.8;
			}
			else if(antiguedad >20){
				montoAntiguedad = CATEGORIA1;
			}
			break;
		}
		case 2:{
			sueldoBasico = CATEGORIA2;
			if(antiguedad <=10){
				montoAntiguedad = CATEGORIA2*0.2;
			}
			else if(antiguedad >=11 && antiguedad <=15){
				montoAntiguedad = CATEGORIA2*0.5;
			}
			else if(antiguedad >=16 && antiguedad <=20){
				montoAntiguedad = CATEGORIA2*0.8;
			}
			else if(antiguedad >20){
				montoAntiguedad = CATEGORIA2;
			}
			break;
		}
		case 3:{
			sueldoBasico = CATEGORIA1;
			if(antiguedad <=10){
				montoAntiguedad = CATEGORIA3*0.2;
			}
			else if(antiguedad >=11 && antiguedad <=15){
				montoAntiguedad = CATEGORIA3*0.5;
			}
			else if(antiguedad >=16 && antiguedad <=20){
				montoAntiguedad = CATEGORIA3*0.8;
			}
			else if(antiguedad >20){
				montoAntiguedad = CATEGORIA3;
			}
			break;
		}
		case 4:{
			sueldoBasico = CATEGORIA1;
			if(antiguedad <=10){
				montoAntiguedad = CATEGORIA4*0.2;
			}
			else if(antiguedad >=11 && antiguedad <=15){
				montoAntiguedad = CATEGORIA4*0.5;
			}
			else if(antiguedad >=16 && antiguedad <=20){
				montoAntiguedad = CATEGORIA4*0.8;
			}
			else if(antiguedad >20){
				montoAntiguedad = CATEGORIA4;
			}
			break;
		}
		default:{ break; }
	}
	sueldoTotal = sueldoBasico + montoAntiguedad;

	cout << "============================================================================" << endl;
	cout << "APELLIDO Y NOMBRE : " << empleado << endl;
	cout << "CATEGORIA : " << categoria << "			" << "SUELDO BÁSICO : $" << sueldoBasico << endl;
	cout << "ANTIGÜEDAD : " << antiguedad << " AÑOS" << "		" << "MONTO ANTIGÜEDAD : $" << montoAntiguedad << endl;
	cout << "SUELDO TOTAL : $ " << sueldoTotal << endl;
}

