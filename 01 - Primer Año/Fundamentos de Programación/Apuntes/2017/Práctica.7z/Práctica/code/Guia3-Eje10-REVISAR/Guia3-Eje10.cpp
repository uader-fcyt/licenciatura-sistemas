
/*
 * Guia3-Eje10.cpp
 *
 *  Created on: 3 oct. 2017
 *      Author: chinosoliard
 *
 *  Ingresar una cadena de caracteres que represente una dirección de correo electrónico.
 *  Se desea validar la dirección para lo cual debe terminar en “.com”, debe tener una @ entre
 *  la segunda posición y al menos una antes de “.com”. Y no debe tener espacios en blanco.
 */

#include <iostream>
#include <string>
using namespace std;

string cadena;

int main(){
	cout << "Ingrese correo electrónico: ";
	cin >> cadena;

	cout << cadena.find(".com", (cadena.size()-4));

}
