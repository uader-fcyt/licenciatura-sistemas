/*
 * Guia3-Eje2.cpp
 *
 *  Created on: 2 oct. 2017
 *      Author: chinosoliard
 *
 *  Ingresar una cadena de caracteres y luego 2 valores que representan la posición inicial
 *  y la final. Informar la subcadena comprendida entre ambas posiciones.
 */

#include <iostream>
#include <string>
using namespace std;

string cadena, subcadena;
int inicio, fin;

int main(){
	cout << "ingrese una cadena de texto: " << endl;
	getline(cin, cadena);
	cout << "Ingrese valor inicial: ";
	cin >> inicio;
	cout << "ingrese valor final: ";
	cin >> fin;

	subcadena = cadena.substr(inicio, fin);

	cout << "La subcadena es: " << endl;
	cout << subcadena;
}

