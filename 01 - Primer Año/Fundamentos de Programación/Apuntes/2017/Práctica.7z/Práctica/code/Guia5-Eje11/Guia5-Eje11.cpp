/*
 * Guia5-Eje11.cpp
 *
 *  Created on: 5 oct. 2017
 *      Author: chinosoliard
 *
 *  Un comercio vende 12 tipos de productos, codificados de 1 a 12. Se ingresa por cada producto,
 *  la descripción y el precio unitario ordenados por código. Además por cada venta realizada de
 *  los productos en el último mes se ingresa: nro. de producto (1 –12) y cantidad vendida.
 *  Puede venir más de una venta por producto. Los datos no vienen ordenados por nro. de producto
 *  y un nro. de producto igual a cero indica el fin de datos.
 *  Se desea:
 *  a) Informar según el siguiente detalle:
 *  NRO . DE PRODUCTO		DESCRIPCIÓN		CANTIDAD TOTAL VENDIDA		IMPORTE TOTAL
 *  1						XXXXXXXXXXX		XXXXX						XXXXX
 *  2						XXXXXXXXXXX		XXXXX						XXXXX
 */

#include <iostream>
#include <string>
using namespace std;

const int cantProductos = 3;

float precios[cantProductos];
string descripciones[cantProductos];
int ventas[cantProductos];
int main(){
	for(int i = 0; i < cantProductos; i++){
		cout << "Ingrese la descripción del producto " << i+1 << ": ";
		cin.get();
		getline(cin, descripciones[i]);
		cout << "Ingrese el precio del producto: ";
		cin >> precios[i];
	}

	cout << "DATOS DE VENTA" << endl;
	int codigo;
	cout << "ingrese el código del producto: ";
	cin >> codigo;
	while (codigo != 0){
		int cantidadVendida = 0;
		cout << "ingrese la cantidad vendida: ";
		cin >> cantidadVendida;
		ventas[codigo-1]+=cantidadVendida;
		cout << "ingrese el código del producto: ";
		cin >> codigo;
	}

	cout << "NRO PRODUCTO		DESCRIPCIÓN		CANTIDAD TOT VENDIDA		IMPORTE TOTAL" << endl;
	for(int i=0; i< cantProductos; i++){
		int totalVenta = ventas[i]*precios[i];
		cout << i+1 << "		" << descripciones[i] << "		" << ventas[i] << "		" << totalVenta << endl;
	}

}
