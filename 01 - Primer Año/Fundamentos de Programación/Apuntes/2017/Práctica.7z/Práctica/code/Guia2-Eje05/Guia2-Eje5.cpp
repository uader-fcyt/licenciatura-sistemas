/*
 * Guia2-Eje5.cpp
 *
 *  Created on: 1 oct. 2017
 *      Author: chinosoliard
 *
 * Ingrese tres números enteros; determine e informe el mayor de ellos.
 */

#include <iostream>
using namespace std;

int numero1, numero2, numero3;

int main(){
	cout << "ingrese el primer número: ";
	cin >> numero1;
	cout << "ingrese el segundo número: ";
	cin >> numero2;
	cout << "ingrese el tercer número: ";
	cin >> numero3;
	if(numero1 > numero2 && numero1 > numero3){
		cout << "El número 1 (" << numero1 << ") es el mayor de los 3 números" << endl;
	}
	else if(numero2 > numero1 && numero2 > numero3){
		cout << "El número 2 (" << numero2 << ") es el mayor de los 3 números" << endl;
	}
	else if(numero3 > numero1 && numero3 > numero1){
			cout << "El número 3 (" << numero3 << ") es el mayor de los 3 números" << endl;
	}
	else {
		cout << "Los números son iguales" << endl;
	}

	return 0;
}


