/*
 * Guia5-Eje04.cpp
 *
 *  Created on: 5 oct. 2017
 *      Author: chinosoliard
 *
 *  Una cooperadora desea obtener la nómina de personas que han adquirido un bono contribución.
 *  Para ello se ingresan los nombres de cada una de las 100 personas que compraron dicho bono,
 *  ordenados por nro. de bono.
 *  Se quiere mostrar al finalizar la carga, un listado con el siguiente formato;
 *  PERSONAS QUE ADQUIRIERON EL BONO
 *  1	XXXXXXXXXXXXXXXXX
 *  2	XXXXXXXXXXXXXXXXX
 *  .....
 */

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

int cantPersonas = 5; //acá va 100

int main(){
	string Personas[cantPersonas];
	for(int i = 0; i<cantPersonas; i++){
		cout << "ingrese apellido y nombre de la persona que compró el bono nº " << i+1 << ": ";
		getline(cin, Personas[i]);
	}

	cout << "PERSONAS QUE ADQUIRIERON EL BONO" << endl;

	for(int i = 0; i<cantPersonas; i++){
		cout << i+1  << setw(4)  << " "<< Personas[i] << endl;
	}
}
