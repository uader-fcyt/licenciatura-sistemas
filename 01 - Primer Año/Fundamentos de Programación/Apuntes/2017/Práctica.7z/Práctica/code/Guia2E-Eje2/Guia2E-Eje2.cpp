/*
 * Guia2E-Eje2.cpp
 *
 *  Created on: 2 oct. 2017
 *      Author: chinosoliard
 *
 *  Dado el ingreso de un mes y un año. Informe la cantidad de días que tiene dicho mes.
 *  Obs: reutilice el código escrito para el cálculo del año bisiesto.
 */

#include <iostream>
using namespace std;

int mes, anio, cantDias;

int main(){
	cout << "Ingrese el mes: ";
	cin >> mes;
	cout << "Ingrese el año: ";
	cin >> anio;

	switch(mes){
	case 1:{
		cantDias = 31;
		break;
	}
	case 2:{
		if((anio % 100 == 0) && (anio % 400 == 0)){
			cantDias = 29;
		}
		else if((anio % 4 == 0) && (anio % 100 == 0)){
			cantDias = 28;
		}
		else if(anio % 4 == 0){
			cantDias = 29;
		}
		break;
	}
	case 3:{
		cantDias = 31;
		break;
	}
	case 4:{
		cantDias = 30;
		break;
	}
	case 5:{
		cantDias = 31;
		break;
	}
	case 6:{
		cantDias = 30;
		break;
	}
	case 7:{
		cantDias = 31;
		break;
	}
	case 8:{
		cantDias = 31;
		break;
	}
	case 9:{
		cantDias = 30;
		break;
	}
	case 10:{
		cantDias = 31;
		break;
	}
	case 11:{
		cantDias = 30;
		break;
	}
	case 12:{
		cantDias = 31;
		break;
	}
	}

	cout << "El mes tiene " << cantDias << " días";
}



