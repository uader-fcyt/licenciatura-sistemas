/*
 * Guia1-Eje3.cpp
 *
 *  Created on: 4 sep. 2017
 *      Author: chinosoliard
 *
 * Determinar e informar, el INDICE DE MASA CORPORAL (IMC) de una persona. Para ello se conoce:
 * el nombre de la persona, su peso (en kgs) y su estatura (en metros).
 * Aplicar la siguiente fórmula: IMC = Peso(kg)/Estatura^2(mts)
 *
 */

#include <iostream>
#include <string>
#include <math.h>
using namespace std;

string nombrePersona;
float pesoKilos, alturaMetros, indiceMasaCorporal;

int main(){
	cout << "Ingrese el nombre de la persona: ";
	getline(cin, nombrePersona);
	cout << "Ingrese el peso (kg) de la persona: ";
	cin >> pesoKilos;
	cout << "Ingrese la estatura (metros) de la persona: ";
	cin >> alturaMetros;
	indiceMasaCorporal = pesoKilos / (pow(alturaMetros,2));
	cout << "El índice de masa corporal de " << nombrePersona << " es de " << indiceMasaCorporal;
	return 0;
}


