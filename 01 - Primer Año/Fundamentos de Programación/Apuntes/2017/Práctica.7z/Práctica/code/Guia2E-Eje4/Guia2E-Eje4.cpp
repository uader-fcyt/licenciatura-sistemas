/*
 * Guia2E-Eje4.cpp
 *
 *  Created on: 2 oct. 2017
 *      Author: chinosoliard
 *
 *  YPF Serviclub otorga puntos canjeables por premios por las cargas de combustibles en sus
 *  estaciones de servicio. Los tipos de combustibles están codificados:
 *  1) Super XXI,
 *  2) Ultra Diesel,
 *  3) N-Premium XXI y
 *  4) D-Euro.
 *  Los puntos se asignan de acuerdo a la siguiente tabla:
 *  	SuperXXI 		3 puntos 	$6,00
 *  	UltraDieselXXI	2 puntos	$4,00
 *  	N-Premium		6 puntos	$10,00
 *  	D-Euro			4 puntos	$10,00
 *  Pero, además, si la carga supera los $250 se duplican los puntos obtenidos, sin importar
 *  el tipo de combustible cargado.
 *  Se ingresan los datos de una carga: el importe cargado y el código del combustible.
 *  Informar los puntos obtenidos por dicha carga.
 */

#include <iostream>
using namespace std;

int codigoCombustible, puntosObtenidos;
float montoCarga;

int main(){
	cout << "Ingrese el importe de la carga: ";
	cin >> montoCarga;
	cout << "Ingrese el típo de combustible: ";
	cin >> codigoCombustible;

	switch(codigoCombustible){
		case 1:{
			puntosObtenidos = ((montoCarga/6)*3);
			if(montoCarga > 250){
				puntosObtenidos*=2;
			}
			break;
		}
		case 2:{
			puntosObtenidos = ((montoCarga/4)*2);
			if(montoCarga > 250){
				puntosObtenidos*=2;
			}
			break;
		}
		case 3:{
			puntosObtenidos = ((montoCarga/10)*6);
			if(montoCarga > 250){
				puntosObtenidos*=2;
			}
			break;
		}
		case 4:{
			puntosObtenidos = ((montoCarga/10)*4);
			if(montoCarga > 250){
				puntosObtenidos*=2;
			}
			break;
		}
		default:{break;}
	}

	cout << "Puntos obtenidos: " << puntosObtenidos;
}


