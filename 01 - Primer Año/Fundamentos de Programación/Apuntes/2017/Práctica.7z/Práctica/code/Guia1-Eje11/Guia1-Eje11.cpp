/*
 * Guia1-Eje11.cpp
 *
 *  Created on: 7 sep. 2017
 *      Author: chinosoliard
 *
 *  Calcular e informar el número de segundos que hay en una hora determinada que se
 *  ingresa de la forma hhmmss.
 *
 */

#include <iostream>
using namespace std;

int horaOriginal, hora, minutos, seg, total;

int main(){
	cout << "Ingrese una hora en formato hhmmss: ";
	cin >> horaOriginal;

	hora = horaOriginal/10000;
	minutos = (horaOriginal-(hora*10000))/100;
	seg = (horaOriginal - (hora*10000)- (minutos*100));

	total = seg+(minutos*60)+ ((hora*60)*60);

	cout << "Total de segundos: " << total << endl;
	return 0;

}


