/*
 * Guia1-Eje7.cpp
 *
 *  Created on: 7 sep. 2017
 *      Author: chinosoliard
 *
 *  Un avión realiza su recorrido partiendo del aeropuerto A, luego se dirige al B, y de allí
 *  al C y culmina su recorrido nuevamente en A.
 *  Se conocen como datos las coordenadas de los puntos A (Xa,Ya), B(Xb,Yb) y C(Xc,Yc).
 *  Se pide:
 *  a. Calcular la distancia que existe entre A y B, entre B y C y entre C y A.
 *  b. Calcular e informar la distancia total que debe recorrer el avión.
 *  La distancia se debe calcular en base a la siguiente fórmula: D= (X2-X1)^2 + (Y2-Y1)^2
 */

#include <iostream>
#include <math.h>
using namespace std;

float ax, ay, bx, by, cx, cy, distanciaAB, distanciaBC, distanciaCA, distanciaTotal;

int main(){
	cout << "Introduzca las coordenadas de A" << endl;
	cout << "Ax: ";
	cin >> ax;
	cout << "Ay: ";
	cin >> ay;
	cout << "Introduzca las coordenadas de B" << endl;
	cout << "Bx: ";
	cin >> bx;
	cout << "By: ";
	cin >> by;
	cout << "Introduzca las coordenadas de C" << endl;
	cout << "Cx: ";
	cin >> cx;
	cout << "Cy: ";
	cin >> cy;
	//  D= (X2-X1)^2 + (Y2-Y1)^2
	distanciaAB = pow((bx-ax),2)+pow((by-ay),2);
	distanciaBC = pow((cx-bx),2)+pow((cy-by),2);
	distanciaCA = pow((ax-cx),2)+pow((ay-cy),2);
	distanciaTotal = distanciaAB+distanciaBC+distanciaCA;
	cout << "==================================" << endl;
	cout << "Distancia entre A y B: " << distanciaAB << endl;
	cout << "Distancia entre B y C: " << distanciaBC << endl;
	cout << "Distancia entre C y A: " << distanciaCA << endl;
	cout << "··································" << endl;
	cout << "Distancia total: " << distanciaTotal;
	return 0;
}

