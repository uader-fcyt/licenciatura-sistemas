/*
 * Guia2-Eje11.cpp
 *
 *  Created on: 1 oct. 2017
 *      Author: chinosoliard
 *
 *  La F.A.V. (Federación Argentina de Voleybol) desea contar con un programa
 *  que indique cual es el equipo ganador de un encuentro. Además debe brindar
 *  un dato estadístico que muy pocas veces sucede, que se da cuando el perdedor
 *  del encuentro termina con más puntos ganados que el equipo ganador.
 *  Los partidos se ganan con dos sets ganados. Se ingresan los nombres de los
 *  equipos, luego los puntos obtenidos por cada uno en los 2 primeros sets y por
 *  último, en el caso de haberse requerido el 3er set, se ingresan los puntos de
 *  dicho set.
 */

#include <iostream>
using namespace std;

int hola;

int main(){

}



