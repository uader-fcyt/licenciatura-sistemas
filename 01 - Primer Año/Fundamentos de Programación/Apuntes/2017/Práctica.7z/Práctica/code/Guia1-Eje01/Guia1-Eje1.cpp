/*
 * Guia1-Eje1.cpp
 *
 *  Created on: 4 sep. 2017
 *      Author: chinosoliard
 *
 * Calcular e informar el perímetro de un cuadrado conociendo el valor del lado.
 */

#include <iostream>
using namespace std;

int lado, perimetroCuadrado;

int main(){
	cout << "Ingrese el tamaño del lado del cuadrado: ";
	cin >> lado;
	perimetroCuadrado = lado*4;
	cout << "El perimetro del cuadrado es: " << perimetroCuadrado;
	return 0;
}


