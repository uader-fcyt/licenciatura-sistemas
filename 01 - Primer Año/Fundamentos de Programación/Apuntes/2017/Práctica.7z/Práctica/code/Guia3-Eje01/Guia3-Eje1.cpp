/*
 * Guia3-Eje1.cpp
 *
 *  Created on: 2 oct. 2017
 *      Author: chinosoliard
 *
 *  Dadas 3 cadenas de caracteres, ordenarlas de acuerdo a su orden alfabético.
 */

#include <iostream>
#include <string>
using namespace std;

string cadena1, cadena2, cadena3, mayor, menor, media;

int main(){
	cout << "ingrese cadena 1: ";
	cin >> cadena1;
	cout << "ingrese cadena 2: ";
	cin >> cadena2;
	cout << "ingrese cadena 3: ";
	cin >> cadena3;

	if((cadena1 > cadena2) && (cadena1 > cadena3)){
		mayor = cadena1;
	}
	else if((cadena2 > cadena1) && (cadena2 > cadena3)){
		mayor = cadena2;
	}
	else if((cadena3 > cadena1) && (cadena3 > cadena2)){
		mayor = cadena3;
	}

	if((cadena1 < cadena2) && (cadena1 < cadena3)){
			menor = cadena1;
	}
	else if((cadena2 < cadena1) && (cadena2 < cadena3)){
			menor = cadena2;
	}
	else if((cadena3 < cadena1) && (cadena3 < cadena2)){
			menor = cadena3;
	}

	if(((mayor == cadena1) || (menor == cadena1)) && ((mayor == cadena2) || (menor == cadena2))){
		media = cadena3;
	}
	else if(((mayor == cadena2) || (menor == cadena2)) && ((mayor == cadena3) || (menor == cadena3))){
		media = cadena1;
	}
	else if(((mayor == cadena1) || (menor == cadena1)) && ((mayor == cadena3) || (menor == cadena3))){
		media = cadena2;
	}

	cout << "Mayor: " << mayor << endl;
	cout << "media: " << media << endl;
	cout << "Menor: " << menor << endl;
}


