/*
 * Guia3-Eje5.cpp
 *
 *  Created on: 3 oct. 2017
 *      Author: chinosoliard
 *
 *  Ingrese una cadena que contenga la palabra “pero”. Reemplace dicha palabra por
 *  “sin embargo”.
 */

#include <iostream>
#include <string>
using namespace std;

string cadenaPero;

int main(){
	cout << "ingrese una cadena que contenga la palabra pero: " << endl;
	getline(cin, cadenaPero);

	if(cadenaPero.find(" pero ")){
		cadenaPero.replace(cadenaPero.find(" pero "), 6, " sin embargo ");
	}

	cout << cadenaPero;
}


