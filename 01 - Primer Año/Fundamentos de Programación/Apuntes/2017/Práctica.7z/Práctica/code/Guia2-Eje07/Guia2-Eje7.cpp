/*
 * Guia2-Eje7.cpp
 *
 *  Created on: 1 oct. 2017
 *      Author: chinosoliard
 *
 * Ingrese un número entero e informe: a) si es par o impar; b) si es múltiplo de 5 y 3 a la vez.
 */

#include <iostream>
using namespace std;

int numero;

int main(){
	cout << "Ingrese un número: ";
	cin >> numero;
	if(numero%2 != 0){
		cout << "El número es impar" << endl;
	}
	else{
		cout << "El número es par" << endl;
	}

	if((numero%3 == 0)&&(numero%5 == 0)){
		cout << "El número es multiplo de 5 y de 3.";
	}
	else{
		cout << "El número no es múltiplo de 5 y de 3.";
	}
}
