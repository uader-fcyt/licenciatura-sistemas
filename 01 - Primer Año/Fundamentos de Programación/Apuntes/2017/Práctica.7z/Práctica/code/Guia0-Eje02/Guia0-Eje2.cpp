/*
 * Eje2.cpp
 *
 *  Created on: 29 ago. 2017
 *      Author: chinosoliard
 *
 *  Se desea contar con una aplicación que, ingresado el sueldo neto de una persona, calcule
 *  su aporte jubilatorio (16% del sueldo neto) y el sueldo líquido (sueldo neto – aporte
 *  jubilatorio).
 */

#include <iostream>
using namespace std;

float sueldoNeto, aporteJubilatorio, sueldoLiquido;

int main(){
	cout << "Ingrese el sueldo del empleado: ";
	cin >> sueldoNeto;
	aporteJubilatorio = sueldoNeto * 0.16;
	sueldoLiquido = sueldoNeto - aporteJubilatorio;
	cout << "Aporte jubilatorio del empleado:" << aporteJubilatorio << endl;
	cout << "Sueldo líquido del empleado:" << sueldoLiquido;
}


